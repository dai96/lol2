﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca
{
    public class Universidad
    {
        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesor;

        public enum EClases
        {
            Programación,
            Laboratorio,
            Legislacion,
            SPD
        }

        public List<Alumno> Alumnos
        {
            get { return this.alumnos; }
            set { this.alumnos= value; }
        }
        public List<Profesor> Profesores
        {
            get { return this.profesor; }
            set { this.profesor = value; }
        }
        public List<Jornada> Jornada
        {
            get { return this.jornada; }
            set { this.jornada = value; }
        }
        public Jornada this[i]
        {
            get { return this.jornada; }
            set { this.jornada = value; }
        }
    }
}
