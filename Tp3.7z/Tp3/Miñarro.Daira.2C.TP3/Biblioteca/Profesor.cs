﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca
{
    sealed class Profesor:Universitario
    {
        private Queue<EClase> clasesDelDia;
        private Random random;

        private void _randomClases()
        { }
        public string MostrarDatos()
        { }
        public static bool operator ==(Profesor i, Eclase clase)
        {
            return true;
        }
        public static bool operator !=(Profesor i, Eclase clase)
        {
            return true;
        }
        public string ParticiparEnClase()
        { }
        public Profesor()
        { }

        private Profesor()
        { }

        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad)
        { }


        public string ToString()
        { return ""; }
    }
}
