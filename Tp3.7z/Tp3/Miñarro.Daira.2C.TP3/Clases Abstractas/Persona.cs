﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exepciones;

namespace Clases_Abstractas
{
    public abstract class Persona
    {
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        private string nombre;

        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
        public string Apellido
        {
            get { return this.apellido; }
            set { this.apellido = this.ValidarNombreApellido(value); }
        }
        public int DNI
        {
            get { return this.dni; }
            set { this.dni = this.ValidarDni(this.Nacionalidad, value); }
        }
        public ENacionalidad Nacionalidad
        {
            get { return this.nacionalidad; }
            set { this.nacionalidad = value; }
        }
        public string Nombre
        {
            get { return this.nombre; }
            set { this.nombre = this.ValidarNombreApellido(value); }
        }
        public string StringToDNI
        {
            set { this.dni = this.ValidarDni(this.Nacionalidad,value);}
        }

        public Persona()
        {
        }
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.DNI = dni;
        }
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }
        public override string ToString()
        {
            StringBuilder stg = new StringBuilder();
            stg.AppendFormat("{0}{1}{2}{3}", this.Apellido, this.Nombre, this.DNI, this.Nacionalidad);
            return stg.ToString();

        }
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            if (nacionalidad==ENacionalidad.Argentino)
            {
                if (dato>=1 && dato<=89999999)
                {
                    return dato;
                }
                else
                {
                    throw new DniInvalidoException();
                }
            }
            else if (nacionalidad==ENacionalidad.Extranjero)
            {
                if (dato >= 90000000 && dato <= 99999999)
                {
                    return dato;
                }
                else
                {
                    throw new DniInvalidoException();
                }
            }
            else
            {
                throw new NacionalidadInvalidaException();
            }
        }
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            return 1;
        }
        private string ValidarNombreApellido(string dato)
        {
            return "";
        }
    }
}
