﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public class Xml<T>
    {
        public bool Guardar(string archivo, string datos)
        {
          
        }


        public bool Leer(string archivo, out string datos)
        {

        }
    }
}
