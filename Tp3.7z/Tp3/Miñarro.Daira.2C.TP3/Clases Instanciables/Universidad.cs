using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exepciones;

namespace Clases_Instanciables
{
  public class Universidad
  {
    private List<Alumno> alumnos;
    private List<Jornada> jornada;
    private List<Profesor> profesor;

    public enum EClases
    {
      Programacion,
      Laboratorio,
      Legislacion,
      SPD
    }

    public List<Alumno> Alumnos
    {
      get { return this.alumnos; }
      set { this.alumnos = value; }
    }
    public List<Profesor> Profesores
    {
      get { return this.profesor; }
      set { this.profesor = value; }
    }
    public List<Jornada> Jornadas
    {
      get { return this.jornada; }
      set { this.jornada = value; }
    }
    public Jornada this[int i]
    {
      get { return this.Jornadas[i]; }
      set { this.Jornadas[i] = value; }
    }

    public bool Guardar(Universidad uni)
    {

    }
    public Universidad Leer()
    {

    }
    private string MostrarDatos(Universidad uni)
    {

    }
    public static bool operator ==(Universidad g, Alumno a)
    {
      foreach (Alumno item in g.alumnos)
       {
        if (item==a)
        {
          return true;
        }
      }
      return false;
    }
    public static bool operator ==(Universidad g, Profesor i)
    {
      foreach (Profesor item in g.Profesores)
      {
        if (item == i)
        {
          return true;
        }
      }
      return false;
    }
    public static Profesor operator ==(Universidad g , EClases clase)
    {
       foreach(Profesor item in g.Profesores)
            {
                if (item==clase)
                {
                    return item;
                }
            }
      return null;
    }
    public static bool operator !=(Universidad g, Alumno a)
    {
      return !(g==a);
    }
    public static bool operator !=(Universidad g, Profesor i)
    {

      return !(g == i);
    }
    public static Profesor operator !=(Universidad g, EClases clase)
    {
      
      return (g==clase);
    }
    public static Universidad operator +(Universidad g, EClases clase)
    {

      return g;
    }
    public static Universidad operator +(Universidad g, Alumno a)
    {
      if (g != a)
      {
        g.Alumnos.Add(a);
      }
      else
      {
        throw new AlumnoRepetidoException();
      }
      return g;
    }
    public static Universidad operator +(Universidad g, Profesor i)
    {
      if (g != i)
      {
        g.Profesores.Add(i);
      }

      return g;
    }
    public string ToString()
    {

    }
    public Universidad()
    {

    }

  }
}
