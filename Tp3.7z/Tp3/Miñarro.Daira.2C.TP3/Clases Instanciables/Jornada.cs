﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_Instanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private Universidad.EClases clase;
        private Profesor instructor;

        public List<Alumno> Alumnos
        {
            get { return this.alumnos; }
            set { this.alumnos = value; }
        }
        public Universidad.EClases Clase
        {
            get { return this.clase; }
            set { this.clase = value; }
        }
        public Profesor Instructor
        {
            get { return this.instructor; }
            set { this.instructor = value; }
        }

        public bool Guardar(Jornada jornada)
        { }
        private Jornada()
        {
            this.Alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clases, Profesor instructor):this()
        {
            this.Clase = clase;
            this.instructor = instructor;
            //this.Instructor = instructor;
        }
        public string Leer()
        { }

        public static bool operator ==(Jornada j, Alumno a)
        {
            return true;
        }
        public static bool operator !=(Jornada j, Alumno a)
        {
            return true;
        }
        public static Jornada operator +(Jornada j, Alumno a)
        {
            return j;
        }
        public string ToString()
        { return ""; }

    }
}
