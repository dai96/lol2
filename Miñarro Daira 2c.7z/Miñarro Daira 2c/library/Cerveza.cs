using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
  public class Cerveza : Botella
  {
    private const int MEDIDA = 330;
    private Tipo tipo;

    public Cerveza(int capacidad, string marca, int contenidoML) : base(marca, capacidad, contenidoML)
    {
      this.tipo = Cerveza.Tipo.Vidrio;
    }
    public Cerveza(int capacidad, string marca, Tipo tipo, int contenidoML) : this(capacidad, marca, contenidoML)
    {
      this.tipo = tipo;
    }
    protected override string GenerarInforme()
    {
      string hola = base.GenerarInforme();
      StringBuilder stringBuild = new StringBuilder();
      stringBuild.AppendFormat("{0}\n", hola);
      stringBuild.AppendFormat("Medida: {0}\n", Cerveza.MEDIDA);
      stringBuild.AppendFormat("Tipo: {0}\n", this.tipo);

      return stringBuild.ToString();
    }
    public override int ServirMedida()
    {
      if (Cerveza.MEDIDA <= this.contenidoML)
      {
        this.contenidoML = contenidoML - Cerveza.MEDIDA;
        return Cerveza.MEDIDA;

      }
      else
      {
        this.contenidoML = 0;
        return this.contenidoML;
      }

    }
    public static implicit operator Botella.Tipo(Cerveza cerveza)
    {
      return cerveza.tipo;
    }
  }
}
