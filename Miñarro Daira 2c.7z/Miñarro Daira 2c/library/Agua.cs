using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
  public class Agua : Botella
  {
    private const int MEDIDA = 400;

    public Agua(int capacidad, string marca, int contenidoML) : base(marca, capacidad, contenidoML)
    { }
    protected override string GenerarInforme()
    {
      string hola = base.GenerarInforme();
      StringBuilder stringBuild = new StringBuilder();
      stringBuild.AppendFormat("{0}\n", hola);
      stringBuild.AppendFormat("Medida: {0}\n", Agua.MEDIDA);
      return stringBuild.ToString();

    }
    public override int ServirMedida()
    {
      if (Agua.MEDIDA <= this.contenidoML)
      {
        this.contenidoML = contenidoML - Agua.MEDIDA;
        return Agua.MEDIDA;
      }
      else
      {
        this.contenidoML = 0;
        return this.contenidoML;
      }
    }
    public int ServirMedida(int medida)
    {
      if (medida <= this.contenidoML)
      {
        int retn;
        retn = medida - 1;
        return retn;
      }
      else
      {
        return this.contenidoML--;
      }
    }
  }
}
