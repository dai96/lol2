﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class Agua:Botella
    {
        private const int MEDIDA = 400;

        public Agua(int capacidad, string marca, int contenidoML) : base(marca, capacidad, contenidoML)
        { }
        protected new string GenerarInforme()
        {
            string hola=base.GenerarInforme();
            StringBuilder stringBuild = new StringBuilder();
            stringBuild.AppendFormat("", hola);
            stringBuild.AppendFormat("Medida: {0}\n", Agua.MEDIDA);
            return stringBuild.ToString();

        }
        public override int ServirMedida()
        {
           if (Agua.MEDIDA<=this.contenidoML)
            {
                return Agua.MEDIDA-1;
            }
           else
            {
                return this.contenidoML--;
            }
        }
        public new int ServirMedida(int medida)
        {
            if (medida <= this.contenidoML)
            {
                return medida - 1;
            }
            else
            {
                return this.contenidoML--;
            }
        }
    }
}
