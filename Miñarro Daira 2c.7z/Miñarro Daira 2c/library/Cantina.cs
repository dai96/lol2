﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class Cantina
    {
        private List<Botella> botellas;
        private int espaciosTotales;
        private Cantina singleton;

        public List<Botella> Botellas
        {
            get { return this.botellas; }
        }

        public Cantina (int espacios)
        {
            this.botellas = new List<Botella>();
            this.espaciosTotales = espacios;
        }
        public Cantina GetCantina(int espacios)
        {
            if (this.singleton==null)
            {
                return  singleton = new Cantina(espacios);
            }
            else
                {
                this.espaciosTotales--;
                return singleton;
            }

        }
        public static bool operator +(Cantina c, Botella b)
        {
            bool rtn = false;
            if (c.espaciosTotales>=1)
            {
                c.botellas.Add(b);
                rtn = true;
            }
            return rtn;
        }

    }
}
