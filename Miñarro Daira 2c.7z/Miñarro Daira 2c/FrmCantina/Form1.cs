using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using library;
using ControlCantina;

namespace FrmCantina
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = Enum.GetValues(typeof(Botella.Tipo));
            this.barra.SetCantina = Cantina.GetCantina(10);
          
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Botella.Tipo tipo;
            Enum.TryParse<Botella.Tipo>(comboBox1.SelectedValue.ToString(), out tipo);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked==true)
            {
              Botella.Tipo tipo;
              Enum.TryParse<Botella.Tipo>(comboBox1.SelectedValue.ToString(), out tipo);
              Cerveza cer = new Cerveza((int)numericUpDown2.Value, textBox1.Text,tipo,(int)numericUpDown1.Value);
              barra.AgregarBotella(cer);
            }
            if (radioButton2.Checked==true)
            {
                Agua agu=new Agua((int)numericUpDown2.Value, textBox1.Text, (int)numericUpDown1.Value);
                barra.AgregarBotella(agu);
            }
           
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
