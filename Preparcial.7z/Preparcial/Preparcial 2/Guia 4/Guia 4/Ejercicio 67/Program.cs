using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ejercicio_67
{
  class Program
  {
    static void Main(string[] args)
    {
    }
  }
  public delegate void EncargadoTiempo();
  sealed class Temporizador
  {
    private Thread hilo;
    private int intervalo;

    public event EncargadoTiempo EventoTiempo;

    public bool Activo
    {
      get {
        this.hilo = new Thread(?);

        public void ? ()


        /*
         * // Creo el hilo
Thread t = new Thread(new ParameterizedThreadStart(Metodo));
// Inicio el Hilo, indicando el parámetro
t.Start(1000);

         * private void Metodo(object o)
{
      Console.WriteLine((int)o);
}

         * */


        return true;
      }
      set {; }
    }
    public int Intervalo
    {
      get {; }
      set {; }
    }
    private void Corriendo()
    {

    }
  }
}
