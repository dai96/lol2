using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Ejercicio_60
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      
      //String connectionStr = "Data Source=lab3pc07\\sqlexpress;Initial Catalog=AdventureWorks2012;Integrated Security=True";

      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.ConectionString);
      SqlCommand comando = new SqlCommand();

      comando.CommandType = System.Data.CommandType.Text;

      comando.Connection = conexion;

      String consulta;
      consulta = "INSERT INTO tabla1 (nombre)  VALUES('Pedro')";

      comando.CommandText = consulta;
      conexion.Open();
      comando.ExecuteNonQuery();
      
      //SELECIONAR COSAS

      comando.CommandText = "SELECT id,nombre";

      SqlDataReader data = comando.ExecuteReader();

      while (data.Read())
      {
        string aux = data["nombre"].ToString();
      }


      data.Close();

      conexion.Close();
    }
  }
}
