using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_68
{
  public delegate void DelegadoString(string msj);

  public class Persona
  {
    public event DelegadoString EventoString;
    private string apellido;
    private string nombre;

    public string Apellido
    {
      get { return this.apellido; }
      set
      {
        
        if (this.apellido != value)
        {
          this.apellido = value;
          EventoString(this.apellido);
        }

        this.apellido = value;
      }

    }
    public string Nombre
    {
      get { return this.nombre; }
      set
      {
        if (this.nombre != value)
        {
          this.nombre = value;
          EventoString(this.nombre);
        }

        this.nombre = value;
      }

    }

    public string Mostrar()
    {
      return String.Format("\nNombre: {0}\nApellido: {1}", this.Nombre, this.Apellido);
    }

    public Persona()
    {
      this.apellido = string.Empty;
      this.nombre = string.Empty;
    }

  }



}

