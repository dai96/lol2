using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_68
{
  public partial class Form1 : Form
  {

    private Persona niu;
 
   


    public Form1()
    {
      InitializeComponent();
    }

    public static void NotificarCambio(string cambio)
    {
      MessageBox.Show(cambio);
    }


    private void Form1_Load(object sender, EventArgs e)
    {
     this.niu = new Persona();
     niu.EventoString += Form1.NotificarCambio;

    }

    private void button1_Click(object sender, EventArgs e)
    {
      
 
      if (this.niu is null)
      {
        this.niu = new Persona();
        button1.Text = "Actualizar";
      }
        niu.Nombre = textBox2.Text;
        niu.Apellido = textBox1.Text;

    }
  }
}








//METODO DE CLASE SIGNIFICA ESTATICO
