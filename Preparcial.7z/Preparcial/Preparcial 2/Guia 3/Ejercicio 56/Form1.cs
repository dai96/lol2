using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ejercicio_56
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            saveFile.AddExtension = true;
            saveFile.DefaultExt = "txt";
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFile.ShowDialog();
            if (File.Exists(openFile.FileName))
            {
                using (StreamReader sr = new StreamReader(openFile.FileName))
                {
                    richTextBox1.Text=sr.ReadToEnd();
                    saveFile.FileName = openFile.FileName;
                }
            }
            else
            {
                throw new FileNotFoundException("\nArchivo no encontrado", openFile.FileName);
            }
        }

        private void guardarCtrlSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFile.FileName == "" && openFile.FileName == "")
            {
                guardarComoToolStripMenuItem_Click(sender, e);
            }
            else
            {
                using (StreamWriter sw = new StreamWriter(saveFile.FileName))
                            {
                                sw.WriteLine(richTextBox1.Text);
                            }
            }
            

        }
        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFile.ShowDialog();
            using (StreamWriter sw = new StreamWriter(saveFile.FileName))
            {
                sw.WriteLine(richTextBox1.Text);
            }

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = String.Format("{0} Caracteres", richTextBox1.Text.Length);
        }

        private void openFile_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}


/*





private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
{
  saveFileDialog1.ShowDialog();
  ArchivoTexto.Guardar(saveFileDialog1.FileName, richTextBox1.Text);
}

private void richTextBox1_TextChanged(object sender, EventArgs e)
{

  toolStripStatusLabel1.Text = String.Format("{0} caracteres", richTextBox1.Text.Length);
  statusStrip1.Refresh();
}

private void guardarToolStripMenuItem1_Click(object sender, EventArgs e)
{
  if (saveFileDialog1.FileName == "" && openFileDialog1.FileName == "")
  {
    guardarComoToolStripMenuItem_Click(sender, e);
  }
  else
  {
    ArchivoTexto.Guardar(saveFileDialog1.FileName, richTextBox1.Text);
  }
}
    }




    static class ArchivoTexto
{
  public static bool Guardar(string path, string datos)
  {
    bool retorno = false;
    using (StreamWriter writer = new StreamWriter(path, false))
    {
      writer.Write(datos);
      retorno = true;
    }
    return retorno;
  }

  public static string Leer(string path)
  {
    if (File.Exists(path))
    {
      using (StreamReader reader = new StreamReader(path))
      {
        return reader.ReadToEnd();
      }
    }
    else
    {
      throw new FileNotFoundException("\nArchivo no encontrado", path);
    }
  }
}
}
*/
