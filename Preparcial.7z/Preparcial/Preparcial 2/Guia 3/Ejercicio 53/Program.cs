﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_53
{
    class Program
    {
        static void Main(string[] args)
        {

            bool retorno;

            Cartuchera1 cartuchera1 = new Cartuchera1();
            Cartuchera2 cartuchera2 = new Cartuchera2();

            Lapiz lapiz1 = new Lapiz(5);
            Lapiz lapiz2 = new Lapiz(1);
            Lapiz lapiz3 = new Lapiz(10);
            cartuchera2.lapices.Add(lapiz1);
            cartuchera2.lapices.Add(lapiz2);
            cartuchera2.lapices.Add(lapiz3);

            Boligrafo boligrafo1 = new Boligrafo(10, ConsoleColor.Blue);
            Boligrafo boligrafo2 = new Boligrafo(2, ConsoleColor.DarkGray);
            Boligrafo boligrafo3 = new Boligrafo(1, ConsoleColor.Magenta);
            cartuchera2.boligrafos.Add(boligrafo1);
            cartuchera2.boligrafos.Add(boligrafo2);
            cartuchera2.boligrafos.Add(boligrafo3);

            do
            {

                retorno = cartuchera2.ProbarElementos();
                Console.WriteLine(retorno);
            } while (retorno == true);
            Console.ReadKey();



            /*
            Console.Title="Ejercicio 53";
            ConsoleColor colorOriginal = Console.ForegroundColor;
            Lapiz miLapiz = new Lapiz(10);
            Boligrafo miBoligrafo = new Boligrafo(20, ConsoleColor.Green);
            EscrituraWrapper eLapiz = ((IAcciones)miLapiz).Escribir("Hola");
            Console.ForegroundColor = eLapiz.color;
            Console.WriteLine(eLapiz.texto);
            Console.ForegroundColor = colorOriginal;
            Console.WriteLine(miLapiz);
            EscrituraWrapper eBoligrafo = miBoligrafo.Escribir("Hola");
            Console.ForegroundColor = eBoligrafo.color; Console.WriteLine(eBoligrafo.texto);
            Console.ForegroundColor = colorOriginal; Console.WriteLine(miBoligrafo);



            Lapiz l1= new Lapiz(5);
            Lapiz l2 = new Lapiz(4);
            Lapiz l3 = new Lapiz(3);
            Boligrafo b1 = new Boligrafo(2, ConsoleColor.DarkMagenta);
            Boligrafo b2 = new Boligrafo(2, ConsoleColor.DarkRed);
            Cartuchera1 c1 = new Cartuchera1();
            Cartuchera2 c2 = new Cartuchera2();
            c2.lapices.Add(miLapiz);
            c2.lapices.Add(l1);
            c2.lapices.Add(l2);
            c2.lapices.Add(l3);
            c2.boligrafos.Add(b1);
            c2.boligrafos.Add(b2);
            c2.boligrafos.Add(miBoligrafo);
            bool rtn;
            do
            {

                rtn = c2.ProbarElementos();
                Console.WriteLine(rtn);
            } while (rtn == true);
            Console.ReadKey();



            Console.ReadKey();*/
        }
    }
}
