﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_52
{
    public class Boligrafo:IAcciones
    {
        private ConsoleColor colorTinta;
        private float tinta;

        public ConsoleColor Color
        {
            get { return this.colorTinta; }
            set {this.colorTinta=value; }
        }
        public float UnidadesDeEscritura
        {
            get { return this.tinta; }
            set { this.tinta= value; }
        }
        public Boligrafo(int unidades, ConsoleColor color)
        {
            this.Color = color;
            this.UnidadesDeEscritura = unidades;
        }
        public EscrituraWrapper Escribir (string texto)
        {
            EscrituraWrapper e = new EscrituraWrapper(texto, this.Color);
            this.UnidadesDeEscritura -= (float)(texto.Length * 0.3);
            return e;
        }
        public bool Recargar (int unidades)
        {
            this.UnidadesDeEscritura += unidades;
            return true;
        }
        public override string ToString()
        {
            return String.Format("\nBoligrafo:\nColor: {0}\nCantidad de tinta: {1}\n", this.Color, this.UnidadesDeEscritura);
        }
    }
    public class Lapiz: IAcciones
    {
        private float tamanioMina;

        ConsoleColor IAcciones.Color
        {
            get { return ConsoleColor.Gray; }
            set { throw new NotImplementedException(); }
        }
        float IAcciones.UnidadesDeEscritura
        {
            get { return this.tamanioMina; }
            set { this.tamanioMina = value; }
        }
        public Lapiz(int unidades)
        {
            ((IAcciones)this).UnidadesDeEscritura = unidades;
        }
        EscrituraWrapper IAcciones.Escribir(string texto)
        {
            EscrituraWrapper e = new EscrituraWrapper(texto, ((IAcciones)this).Color);
            ((IAcciones)this).UnidadesDeEscritura -= (float)(texto.Length * 0.1);
            return e;
        }
        bool IAcciones.Recargar(int unidades)
        {
            throw new NotImplementedException();
        }
        public override string ToString()
        {

            return String.Format("\nLapiz:\nColor: {0}\nTamaño mina: {1}", ((IAcciones)this).Color, ((IAcciones)this).UnidadesDeEscritura);
        }
    }
    
    public class EscrituraWrapper
    {
        public ConsoleColor color;
        public string texto;

        public EscrituraWrapper(string texto, ConsoleColor color)
        {
            this.texto = texto;
            this.color = color;
        }


    }
    public interface IAcciones
    {
         ConsoleColor Color
        {
            get; 
            set;
        }
        float UnidadesDeEscritura
        {
            get;
            set;
        }
        EscrituraWrapper Escribir(string texto);
        bool Recargar(int unidades);
    }
}
