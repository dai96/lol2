﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Practica
{
    class Program
    {
        static void Main(string[] args)
        {

            Thread miHilo;

            public FrmPrueba()
            {
                InitializeComponent();

                this.miHilo = new Thread(this.AnimarCaballito);
            }

            private void btnIniciar_Click(object sender, EventArgs e)
            {
                if (this.miHilo.IsAlive)
                {
                    this.miHilo.Abort();
                }
                else
                {
                    this.miHilo = new Thread(this.AnimarCaballito);
                    this.miHilo.Start();
                }
            }

            private void AnimarCaballito()
            {

                do
                {
                    caballito1.MoverCaballito();
                    Thread.Sleep(45);
                } while (true);
            }

            private void FrmPrueba_FormClosing(object sender, FormClosingEventArgs e)
            {
                if (miHilo.IsAlive)
                    miHilo.Abort();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Temporizador t = new Temporizador(1000);
            t.evento += T_evento;
            System.Threading.Thread hilo = new System.Threading.Thread(t.Run);
            hilo.Start();
        }

        private void T_evento()
        {
            if (this.lblMostrar.InvokeRequired)
            {
                TempDelegado d = new TempDelegado(T_evento);
                this.Invoke(d);
            }
            else
            {
                this.lblMostrar.Text = DateTime.Now.ToString();
            }
        }
    }
}
+

CABALLOS

    public partial class frmCarrera : Form
{
    private List<Animal> carrera;
    private List<Thread> carreraHilos;

    public frmCarrera()
    {
        InitializeComponent();

        this.carrera = new List<Animal>();
        this.carreraHilos = new List<Thread>();
    }

    private void LimpiarCarriles()
    {
        this.FinalizarCarrera();

        carril1.Location = new Point(2, carril1.Location.Y);
        carril2.Location = new Point(2, carril2.Location.Y);
        carril3.Location = new Point(2, carril3.Location.Y);
        carril4.Location = new Point(2, carril4.Location.Y);

        this.carrera.Clear();
    }

    public void FinalizarCarrera()
    {
        foreach (Thread t in this.carreraHilos)
        {
            if (t.IsAlive)
                t.Abort();
        }

        this.carreraHilos.Clear();
    }

    private void btnIniciar_Click(object sender, EventArgs e)
    {
        this.LimpiarCarriles();

        //this.carrera.Add(new Humano(30, 1));
        //this.carrera.Add(new Humano(30, 2));
        //this.carrera.Add(new Humano(30, 3));
        //this.carrera.Add(new Humano(30, 4));
        this.carrera.Add(new Caballo("Silver", 30, 1));
        this.carrera.Add(new Caballo("Rocinante", 30, 2));
        this.carrera.Add(new Caballo("Pegaso", 30, 3));
        this.carrera.Add(new Caballo("Perdigón", 30, 4));

        foreach (Animal a in this.carrera)
        {
            a.AvisoAvance += this.Corren;
            this.carreraHilos.Add(new Thread(a.Correr));
        }
        // Para que no haya supuestas ventajas, inicio todos después
        foreach (Thread t in this.carreraHilos)
        {
            t.Start();
        }
    }

    private void HayGanador(int carril)
    {
        this.FinalizarCarrera();
        MessageBox.Show(String.Format("Ganador carril Nº {0}", carril), "GANADOR!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        if (carril == nudCarril.Value)
        {
            MessageBox.Show("FELICITACIONES!!");
            lblTengo.Text = (int.Parse(lblTengo.Text) + (int)nudApuesta.Value).ToString();
        }
        else
        {
            MessageBox.Show("Será la próxima.");
            lblTengo.Text = (int.Parse(lblTengo.Text) - (int)nudApuesta.Value).ToString();
            if (int.Parse(lblTengo.Text) <= 0)
            {
                MessageBox.Show("Chau!");
                this.Close();
            }
        }
    }

    private void AnalizarCarrera(Caballitos.Caballito carril, int avance, int carrilNro)
    {
        int maximum = Screen.AllScreens[0].WorkingArea.Width - 180;
        int valor = 0;
        valor = carril.Location.X + avance;
        carril.MoverCaballito();
        if (valor <= maximum)
            carril.Location = new Point(valor, carril.Location.Y);
        else
        {
            carril.Location = new Point(maximum, carril.Location.Y);
            this.HayGanador(carrilNro);
        }
    }
    //delegate void CorrenCallback(int avance, int carril);
    private void Corren(int avance, int carril)
    {
        if (carril1.InvokeRequired)
        {
            AvisoAvanceCallback d = new AvisoAvanceCallback(Corren);
            object[] objs = new object[] { avance, carril };
            this.Invoke(d, objs);
        }
        else
        {
            switch (carril)
            {
                case 1:
                    AnalizarCarrera(carril1, avance, carril);
                    break;
                case 2:
                    AnalizarCarrera(carril2, avance, carril);
                    break;
                case 3:
                    AnalizarCarrera(carril3, avance, carril);
                    break;
                case 4:
                    AnalizarCarrera(carril4, avance, carril);
                    break;
            }
        }
    }

    private void FrmCarrera_Load(object sender, EventArgs e)
    {

    }
}





test UNITARIO

    using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Ejercicio_44
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestCentralitaInicializada()
        {
            Centralita centralita = new Centralita();
            Centralita centralita2 = new Centralita("Centralita");
            Assert.IsNotNull(centralita.Llamadas);
            Assert.IsNotNull(centralita2.Llamadas);
        }

        [TestMethod]
        public void TestCentralitaExceptionLocal()
        {
            Centralita centralita = new Centralita();
            Local local = new Local("111", 20, "222", 400);
            Local local2 = new Local("111", 4330, "222", 300);

            try
            {
                centralita += local;
                centralita += local2;
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(CentralitaException));
            }
        }

        [TestMethod]
        public void TestCentralitaExceptionProvincial()
        {
            Centralita centralita = new Centralita();
            Provincial provincial = new Provincial("111", Provincial.Franja.Franja_1, 544, "222");
            Provincial provincial2 = new Provincial("111", Provincial.Franja.Franja_2, 478, "222");

            try
            {
                centralita += provincial;
                centralita += provincial2;
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(CentralitaException));
            }
        }

        [TestMethod]
        public void TestLlamadasComparacion()
        {
            Local local = new Local("111", 20, "222", 400);
            Local local2 = new Local("111", 4330, "222", 300);
            Provincial provincial = new Provincial("111", Provincial.Franja.Franja_1, 544, "222");
            Provincial provincial2 = new Provincial("111", Provincial.Franja.Franja_2, 478, "222");
            Assert.IsTrue(local == local2);
            Assert.IsFalse(local == provincial);
            Assert.IsFalse(local == provincial2);

            Assert.IsTrue(local2 == local);
            Assert.IsFalse(local2 == provincial);
            Assert.IsFalse(local2 == provincial2);

            Assert.IsFalse(provincial == local);
            Assert.IsFalse(provincial == local2);
            Assert.IsTrue(provincial == provincial2);

            Assert.IsFalse(provincial2 == local);
            Assert.IsFalse(provincial2 == local2);
            Assert.IsTrue(provincial2 == provincial);
        }
    }
}





interface acciones con implicita/explicita

        public class Boligrafo : IAcciones
{
    private ConsoleColor colorTinta;
    private float tinta;

    public ConsoleColor Color
    {
        get { return this.colorTinta; }
        set { this.colorTinta = value; }
    }
    public float UnidadesDeEscritura
    {
        get { return this.tinta; }
        set { this.tinta = value; }
    }
    public Boligrafo(int unidades, ConsoleColor color)
    {
        this.Color = color;
        this.UnidadesDeEscritura = unidades;
    }
    public EscrituraWrapper Escribir(string texto)
    {
        EscrituraWrapper e = new EscrituraWrapper(texto, this.Color);
        this.UnidadesDeEscritura -= (float)(texto.Length * 0.3);
        return e;
    }
    public bool Recargar(int unidades)
    {
        this.UnidadesDeEscritura += unidades;
        return true;
    }
    public override string ToString()
    {
        return String.Format("\nBoligrafo:\nColor: {0}\nCantidad de tinta: {1}\n", this.Color, this.UnidadesDeEscritura);
    }
}
public class Lapiz : IAcciones
{
    private float tamanioMina;

    ConsoleColor IAcciones.Color
    {
        get { return ConsoleColor.Gray; }
        set { throw new NotImplementedException(); }
    }
    float IAcciones.UnidadesDeEscritura
    {
        get { return this.tamanioMina; }
        set { this.tamanioMina = value; }
    }
    public Lapiz(int unidades)
    {
        ((IAcciones)this).UnidadesDeEscritura = unidades;
    }
    EscrituraWrapper IAcciones.Escribir(string texto)
    {
        EscrituraWrapper e = new EscrituraWrapper(texto, ((IAcciones)this).Color);
        ((IAcciones)this).UnidadesDeEscritura -= (float)(texto.Length * 0.1);
        return e;
    }
    bool IAcciones.Recargar(int unidades)
    {
        throw new NotImplementedException();
    }
    public override string ToString()
    {

        return String.Format("\nLapiz:\nColor: {0}\nTamaño mina: {1}", ((IAcciones)this).Color, ((IAcciones)this).UnidadesDeEscritura);
    }
}

public class EscrituraWrapper
{
    public ConsoleColor color;
    public string texto;

    public EscrituraWrapper(string texto, ConsoleColor color)
    {
        this.texto = texto;
        this.color = color;
    }


}
public interface IAcciones
{
    ConsoleColor Color
    {
        get;
        set;
    }
    float UnidadesDeEscritura
    {
        get;
        set;
    }
    EscrituraWrapper Escribir(string texto);
    bool Recargar(int unidades);
}
}
 public class Cartuchera1
{
    public List<IAcciones> acciones;

    public Cartuchera1()
    {
        this.acciones = new List<IAcciones>();
    }
    public bool probarElementos()
    {
        foreach (IAcciones item in this.acciones)//ESTO ES RECORRER LA LISTA
        {
            if (item.UnidadesDeEscritura - 1 > 0)
            {
                item.UnidadesDeEscritura = -1;
            }
            else if (item.UnidadesDeEscritura - 1 == 0)
            {
                item.UnidadesDeEscritura -= 1;
                item.Recargar(5);
            }
            else
            {
                return false;
            }
        }
        return true;
    }
}

public class Cartuchera2
{
    public List<Lapiz> lapices;
    public List<Boligrafo> boligrafos;

    public Cartuchera2()
    {
        this.lapices = new List<Lapiz>();
        this.boligrafos = new List<Boligrafo>();

    }
    public bool ProbarElementos()
    {
        foreach (Lapiz item in this.lapices)//ESTO ES RECORRER LA LISTA
        {
            if (((IAcciones)item).UnidadesDeEscritura - 1 > 0)
            {
                ((IAcciones)item).UnidadesDeEscritura = -1;
            }
            else if (((IAcciones)item).UnidadesDeEscritura - 1 == 0)
            {
                ((IAcciones)item).UnidadesDeEscritura -= 1;
                ((IAcciones)item).Recargar(5);
            }
            else
            {
                return false;
            }
        }
        foreach (Boligrafo item in this.boligrafos)//ESTO ES RECORRER LA LISTA
        {
            if (item.UnidadesDeEscritura - 1 > 0)
            {
                item.UnidadesDeEscritura = -1;
            }
            else if (item.UnidadesDeEscritura - 1 == 0)
            {
                item.UnidadesDeEscritura -= 1;
                item.Recargar(5);
            }
            else
            {
                return false;
            }
        }
        return true;
    }
}
}
//ASI SE PRUEBA

     Cartuchera1 cartuchera1 = new Cartuchera1();
Cartuchera2 cartuchera2 = new Cartuchera2();

Lapiz lapiz1 = new Lapiz(5);
Lapiz lapiz2 = new Lapiz(1);
Lapiz lapiz3 = new Lapiz(10);
cartuchera2.lapices.Add(lapiz1);
            cartuchera2.lapices.Add(lapiz2);
            cartuchera2.lapices.Add(lapiz3);

            Boligrafo boligrafo1 = new Boligrafo(10, ConsoleColor.Blue);
Boligrafo boligrafo2 = new Boligrafo(2, ConsoleColor.DarkGray);
Boligrafo boligrafo3 = new Boligrafo(1, ConsoleColor.Magenta);
cartuchera2.boligrafos.Add(boligrafo1);
            cartuchera2.boligrafos.Add(boligrafo2);
            cartuchera2.boligrafos.Add(boligrafo3);


    DELEGADOS ASI SE DECLARAN

     public delegate void DelegadoString(string msj);

public class Persona
{
    public event DelegadoString EventoString;





    ASI SE HACEN XLM Y INTERFAZ
        public class SerializarXML<T> : IArchivos<T>
    {
        public T Leer(string rutaArchivo, T objeto)
        {
            using (TextReader reader = new StreamReader(rutaArchivo))
            {

                XmlSerializer serializer = new XmlSerializer(typeof(T));
                objeto = (T)serializer.Deserialize(reader);
                if (objeto is T)
                {
                    return (T)objeto;
                }
                else
                {
                    throw new ErrorArchivoException();
                }
            }
        }
        public bool Guardar(string rutaArchivo, T objeto)
        {
            using (TextWriter writer = new StreamWriter(rutaArchivo))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                serializer.Serialize(writer, objeto);
                if (objeto is T)
                {
                    return true;
                }
                else
                {
                    throw new ErrorArchivoException();
                }
            }

        }

    }