﻿public enum TipoLlamada
{
    Local,
    Provinicial,
    Todas
}