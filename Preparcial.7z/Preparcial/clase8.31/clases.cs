using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace clase8._31
{
    public class Cliente
    {
        private string nombre;
        private int numero;

        public string Nombre //esto tiene que estar siempr en public
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public int Numero
        {
            get { return numero; }
        }
        public Cliente(int numero)
        {
            this.numero = numero;
        }
        public Cliente(int numero, string nombre) : this(numero)
        {
            this.nombre = nombre;
        }

        public static bool operator ==(Cliente c1, Cliente c2)
        {
            if (c1.numero==c2.numero)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(Cliente c1, Cliente c2)
        {
            return !(c1 == c2);
        }
    }
    public class Negocio
    {
        private PuestoAtencion caja;
        private Queue<Cliente> clientes;
        private string nombre;

        Cliente Cliente
        {
            get { return this.clientes.Dequeue(); }
            set { this.clientes.Enqueue (value); }
        }

        private Negocio ()
        {
            this.caja = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
            this.clientes = new Queue<Cliente>();
        }
        public Negocio(string nombre): this()
        {
            this.nombre = nombre;
        }
        public static bool operator ==(Negocio n, Cliente c)
        {
            foreach(Cliente item in n.clientes)
            {
                if (item==c)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Negocio n, Cliente c)
        {
            return !(n == c);
        }
        public static bool operator +(Negocio n, Cliente c)
        {
           if (n!=c)
            {
                n.clientes.Enqueue(c);
                return true;
            }
            return false;
        }
        public static bool operator ~(Negocio n)
        {
            return n.caja.Atender(n.Cliente);
        }
    }
    public class PuestoAtencion
    {
        private static int numeroActual;
        private Puesto puesto;
        public enum Puesto
        {
            Caja1,
            Caja2
        }

        public static int NumeroActual
        {
            get { return numeroActual + 1; }
        }

        public bool Atender(Cliente cli)
        {
            Thread.Sleep(1500);
            return true;

        }

        private PuestoAtencion()
        {
            PuestoAtencion.numeroActual = 0;
        }

        public PuestoAtencion(Puesto puesto):this()
        {
            this.puesto = puesto;
        }


    }

}


//explicito conciente
//implicito solo 

