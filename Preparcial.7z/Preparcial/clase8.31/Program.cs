using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase8._31
{
  class Program
  {
    static void Main(string[] args)
    {
            bool algo = false;
            Negocio negocio = new Negocio("coto");
            Cliente c1 = new Cliente(25, "Daira");
            Cliente c2 = new Cliente(26, "Pedro");
            Cliente c3 = new Cliente(21, "Mosca");

            algo = negocio + c1;
            algo = negocio + c2;
            algo = negocio + c3;
            Console.WriteLine("{0} {1}",c1.Nombre,c1.Numero);
            Console.WriteLine("{0} {1}", c2.Nombre, c2.Numero);
            Console.WriteLine("{0} {1}", c3.Nombre, c3.Numero);

            Console.ReadLine();

        }
  }
}
