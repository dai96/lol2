﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#pragma warning disable CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
namespace CosasParcial
{
    public int Dni
    {
        get { return this.dni; }
        set { this.dni = value; }
    }

    bool hola;
    Equipo equipo = new Equipo(5, "ALTO EQUIPO");
    Jugador j1 = new Jugador(39462131, "Daira");
    hola = equipo + j1;
    Console.WriteLine(j1.MostrarDatos());


        public override string Mostrar(Banco b)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat(b.Mostrar());
        sb.AppendFormat("Pais : {0}", ((BancoNacional)b).pais);
        return sb.ToString();
    }
    EN LOS MOSTRAR CON DIFERENCIA DEBERIA DE SEPARAR SEGUN CLASES

    public BancoMunicipal(BancoProvincial provincial, string municipio) : base(new BancoNacional(provincial.nombre, provincial.pais), provincial.provincia)
    {
        this.municipio = municipio;
    }

    public static implicit operator string(BancoMunicipal bM)
    {
        return "Nombre: " + bM.nombre + " - Pais:" + bM.pais + " - Provincia: " + bM.provincia + " - Municipio: " + bM.municipio;
    }

    public override bool Equals(object obj)
    {

        bool flag = false;

        if (obj is Banco)
        {
            if (this.nombre == ((Banco)obj).nombre)
            {
                MessageBox.Show("Es un banco y tiene el mismo nombre");
                flag = true;
            }
            else
            {
                MessageBox.Show("Es un banco pero no tiene el mismo nombre");
            }
        }
        else if (obj is BancoNacional)
        {
            MessageBox.Show("Es un banco nacional");
        }
        else if (obj is BancoProvincial)
        {
            MessageBox.Show("Es un banco provincial");
        }
        else if (obj is BancoMunicipal)
        {
            MessageBox.Show("Es un banco municipal");
        }
        else
        {
            MessageBox.Show("No es ningun tipo de banco");
        }

        return flag;
    }


    public static List<Producto> operator +(Deposito a, Deposito b)
    {
        //Creamos nueva lista
        List<Producto> nuevaLista = new List<Producto>();

        foreach (Producto p1 in a.productos)
        {
            foreach (Producto p2 in b.productos)
            {
                if (p1.nombre == p2.nombre)
                {
                    p1.stock += p2.stock;
                }
                else
                {
                    nuevaLista.Add(p2);
                }
            }

            nuevaLista.Add(p1);
        }

        return nuevaLista;
    }

    public static void OrdenarAlfabetico(Deposito d1)
    {
        d1.productos.Sort((p, q) => string.Compare(p.nombre, q.nombre));
    }

    public static void OrdenarAscendente(Deposito d1)
    {
        d1.productos.Sort((p, q) => p.stock.CompareTo(q.stock));
    }
    public static string Mostrar(Biblioteca biblioteca)
    {
        StringBuilder stringBuild = new StringBuilder();
        stringBuild.AppendFormat("Capacidad de la biblioteca: {0}\n", biblioteca._capacidad);
        stringBuild.AppendFormat("Total por Manuales: $ {0:#.##}\n", biblioteca.PrecioDeManuales);
        stringBuild.AppendFormat("Total por Novelas: $ {0:#.##}\n", biblioteca.PrecioDeNovelas);
        stringBuild.AppendFormat("Total: $ {0:#.##}\n", biblioteca.PrecioTotal);
        stringBuild.AppendLine("****************************************");
        stringBuild.AppendLine("Listado de Libros");
        stringBuild.AppendFormat("****************************************");

        foreach (Libro libro in biblioteca._libros)
        {
            stringBuild.AppendLine("");
            if (libro is Manual)
            { stringBuild.AppendLine(((Manual)libro).Mostrar()); }
            else if (libro is Novela)
            { stringBuild.AppendLine(((Novela)libro).Mostrar()); }
        }

        return stringBuild.ToString();
    }
    private double ObtenerPrecio(ELibro tipoLibro)
    {
        double retorno = 0;

        foreach (Libro libro in this._libros)
        {
            switch (tipoLibro)
            {
                case ELibro.Manual:
                    if (libro is Manual)
                    {
                        retorno += ((Manual)libro);
                    }
                    break;
                case ELibro.Novela:
                    if (libro is Novela)
                    {
                        retorno += ((Novela)libro);
                    }
                    break;
                default:
                    break;
            }
        }

        return retorno;
    }

    public void CalcularFinal()
    {
        Thread.Sleep(150);
        Random rdn = new Random();
        int nota;
        if (this.nota1 > 4 && this.nota2 > 4)
        {
            nota = rdn.Next(1, 10);
            this.notaFinal = nota;
        }
        else
        {
            this.notaFinal = -1;

        }
    }

    class Libro
    {
        private List<string> paginas;
        public Libro()
        {
            this.paginas = new List<string>();
        }
        public string this[int i]
        {
            get
            {
                if (i >= 0 && i < this.paginas.Count)
                {
                    return paginas[i];
                }
                return "lolno";

            }
            set
            {
                if (i > this.paginas.Count)
                {
                    this.paginas.Add(value);
                }
                else if (i >= 0)
                {
                    this.paginas.Insert(i, value);
                }


            }
        }


    }


    public static bool operator +(Equipo e, Jugador j)
    {
        if (e.jugadores.Count(esto es una liosta) <= e.cantidadDeJugadores)
        {
            foreach (Jugador item in e.jugadores)
            {
                if (item == j)
                {
                    return false;
                }
            }
        }

        e.jugadores.Add(j);

        return true;
    }

    //                                                            C.competidores es una list
    
    public static bool operator +(Competencia c, AutoF1 a)
    {
        Thread.Sleep(150);
        Random random = new Random();
        if (c.competidores.Count (esto es list)< c.cantidadCompetidores)
        {
            if (c != a)
            {
                a.EnCompetencia = true;
                a.VueltasRestantes = c.cantidadVueltas;
                a.CantidadCombustible = (short)random.Next(15, 100);
                c.competidores.Add(a);
                return true;
            }
        }
        return false;
    }

    public string MostrarDatos()
    {
        StringBuilder myStg = new StringBuilder();
        myStg.Append("\ncantidad de Competidores: " + this.cantidadCompetidores + " Cantidad de vueltas: " + this.cantidadVueltas);
        foreach (AutoF1 item in this.competidores)
        {
            myStg.AppendFormat(item.MostrarDatos());
        }
        return myStg.ToString();
    }





}
#pragma warning restore CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()

