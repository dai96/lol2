﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void NoAgregaExcepcion()
        {
            try
            {
                Fruta v1 = new Fruta((float)2.5, ReinoVegetal.Gusto.Dulce, ConsoleColor.Red);
                Canasta<Fruta> canasta1 = new Canasta<Fruta>(0);

                canasta1 += v1;
            }
            catch (NoAgregaException)
            { Assert.IsTrue(true); }
        }
    }
}
