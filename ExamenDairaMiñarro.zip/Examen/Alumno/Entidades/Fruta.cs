﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Fruta:ReinoVegetal, IVegetales
    {
        private ConsoleColor color;

        public ConsoleColor Colores
        {
            get { return this.color; }
        }
        public Fruta(float valor, Gusto gusto, ConsoleColor color):base(valor,gusto)
        {
            this.color = color;
        }
        public string mostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}", this.color);
            return sb.ToString();
        }
    }
}
