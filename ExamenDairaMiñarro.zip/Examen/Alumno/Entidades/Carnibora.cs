﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Carnibora:ReinoVegetal, IVegetales
    {
        // Tipos del enumerado: Pinzas, Pelos, Caída, Mecánicas, Combinada
        private Captura tipo;
        private int tamanio;

        public Carnibora(float valor, Gusto gusto, Captura tipo):base(valor,gusto)
        {
            this.tipo = tipo;
        }

        public Carnibora(float valor, Gusto gusto, Captura tipo, int tamanio):this(valor,gusto,tipo)
        {
            this.tamanio = tamanio;
        }
        public Captura Capturas
        {
            get { return this.tipo; }
        }
        public enum Captura
        {
            Pinzas,
            Pelos,
            Caída,
            Mecánicas,
            Combinada
        }
        public string mostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}{1}", this.tipo, this.tamanio);
            return sb.ToString();
        }
    }
}
