﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Verdura:ReinoVegetal,IVegetales
    {
        // Tipos del enumerado Semilla, Raíz, Tubérculo, Bulbo, Tallo, Hoja, Inflorescencia, Rizoma
        private TipoVerdura tipo;
        public TipoVerdura Tipos
        {
            get { return this.tipo; }
        }
        public Verdura(float valor, Gusto gusto, TipoVerdura tipo):base(valor,gusto)
        {
            this.tipo = tipo;
        }
        public enum TipoVerdura
        {
            Semilla,
            Raíz,
            Tubérculo,
            Bulbo,
            Tallo,
            Hoja,
            Inflorecencia,
            Rizoma

        }
       public string mostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}", this.tipo);
            return sb.ToString();
        }
    }
}
