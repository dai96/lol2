﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class ReinoVegetal
    {
        // Tipos del enumerado Dulce, Salado, Toxica

        private static Random calcularValor;
        protected float valor;
        protected Gusto gusto;

        public ReinoVegetal(Gusto gusto) : this(0, gusto)
        {
            this.valor = calcularValor.Next(1, 100);
        }

        public ReinoVegetal(float valor, Gusto gusto)
        {
            this.valor = valor;
            this.gusto = gusto;
        }
        static ReinoVegetal()
        {
            ReinoVegetal.calcularValor = new Random();
        }
        public enum Gusto
        {
            Dulce,
            Salado,
            Toxica
        }
        public static bool operator ==(ReinoVegetal p1, ReinoVegetal p2)
         {
            if (p1.GetType()==p2.GetType())
            {
                if (p1.gusto==p2.gusto)
                {
                    return true;
                }
            }
            return false;
         }
        public static bool operator !=(ReinoVegetal p1, ReinoVegetal p2)
        {
            return !(p1 == p2);
        }
    }
}
