﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Entidades
{
    public static class GuardarElemento
    {
        public static Fruta MostrarElemento(this Fruta texto)
        {
            return texto;
        }
        public static Fruta Guardar(this Fruta texto)
        {
            string archivo = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"datos.txt\";


            if (File.Exists(archivo))
            {
                using (StreamWriter sw = new StreamWriter(archivo, true))
                {
                    sw.WriteLine(texto);
                }
            }
            else
            {
                using (StreamWriter sw = new StreamWriter(archivo, false))
                {
                    sw.WriteLine(texto);
                }
            }

            return texto;

        }
        public static bool GuardarXML(this Fruta datos)
        {
            string archivo = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"datos.xml\";
            using (TextWriter writer = new StreamWriter(archivo))
            {
                XmlSerializer xml = new XmlSerializer(typeof(Fruta));
                xml.Serialize(writer, datos);
                return true;
            }
        }

        public static bool LeerXML(out Fruta datos)
        {
            string archivo = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"datos.xml\";
            using (TextReader reader = new StreamReader(archivo))
            {
                XmlSerializer xml = new XmlSerializer(typeof(Fruta));
                datos = (Fruta)xml.Deserialize(reader);
                return true;
            }

        }


    }
}
