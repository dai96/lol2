﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Canasta<T>
    {
        private List<T> plantas;
        private short capacidad;

        private Canasta()
         {
            this.plantas = new List<T>();
         }

        public Canasta(short capacidad):this()
        {
            this.capacidad = capacidad;
        }

        public static Canasta<T> operator +(Canasta<T> c, ReinoVegetal reinoVegetal)
        {
            if (reinoVegetal is T)
            {
                if (c.plantas.Count < c.capacidad)
                {
                    T aux = (T)Convert.ChangeType(reinoVegetal, typeof(T)); 
                    c.plantas.Add(aux);

                    return c;
                }
                else
                {
                    throw new NoAgregaException("Capacidad excedida");
                }
            }
            else
            {
                throw new NoAgregaException(string.Format("El elemento es del tipo {0}. Se esperaba {1}.", reinoVegetal.GetType(), c.GetType()));
            }
        }


        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad: " + this.capacidad);
            foreach (T reinoVegetal in this.plantas)
            {
               // sb.AppendLine(reinoVegetal.mostrarDatos());// ESTO NO ME FUNCIONA
            }
            return sb.ToString();
        }
    }
}
