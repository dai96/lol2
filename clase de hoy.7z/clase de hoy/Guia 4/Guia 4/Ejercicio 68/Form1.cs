using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_68
{
  public partial class Form1 : Form
  {

    private Persona niu;
    private event DelegadoString evento;


    public Form1()
    {
      InitializeComponent();
    }

    public void NotificarCambio(string cambio)
    {
      MessageBox.Show(cambio);
    }


    private void Form1_Load(object sender, EventArgs e)
    {
     

    }

    private void button1_Click(object sender, EventArgs e)
    {
      if (this.niu is null)
      {
        this.niu = new Persona();
        button1.Text = "Actualizar";
        this.evento(String.Format("Se ha creado la persona {0}", this.niu.Mostrar()));
      }
      else
      {
        this.niu = new Persona();
        this.evento(String.Format("Se ha actualizado la persona: {0}", this.niu.Mostrar()));
      }
    }
  }
}



