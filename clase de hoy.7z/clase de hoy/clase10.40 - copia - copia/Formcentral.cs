using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clase10._40
{
    public partial class Formcentral : Form
    {
        public Formcentral()
        {
            InitializeComponent();
            
        }

        private void Button1_Click(object sender, EventArgs e)
        {
         FormLlamador frm = new FormLlamador();
         frm.Show();
        }

    private void Formcentral_Load(object sender, EventArgs e)
    {
      Centralita c = new Centralita("prueba");
      Local l1 = new Local("Bernal", 30, "Rosario", 2.65f);
      Local l2 = new Local("Bernal", 30, "Rosario", 2.65f);
      try
      {
        c += l1;
        c += l2;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }

  
    }
  }
}
