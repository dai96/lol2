﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase7._29
{
    class Program
    {
        static void Main(string[] args)
        {
            bool hola;
            Equipo equipo = new Equipo(5, "ALTO EQUIPO");
            Jugador j1 = new Jugador(39462131, "Daira");
            Jugador j2 = new Jugador(39462132, "Pedro");
            Jugador j3 = new Jugador(39462133, "Natalia", 8, 2);
            Jugador j4 = new Jugador(39462134, "Mario", 0, 2);
            Jugador j5 = new Jugador(39462135, "Naiara");
            Jugador j6 = new Jugador(39462136, "Pablo");

            hola= equipo + j1;
            hola= equipo + j2;
            hola= equipo + j3;
            hola= equipo + j4;
            hola= equipo + j5;
            hola= equipo + j6;

            Console.WriteLine(j1.MostrarDatos());
            Console.WriteLine(j2.MostrarDatos());
            Console.WriteLine(j3.MostrarDatos());
            j3.GetPromedioGoles();
            Console.WriteLine(j3.MostrarDatos());
            j4.GetPromedioGoles();
            Console.WriteLine(j4.MostrarDatos());
            Console.ReadLine();
        }
    }
}
