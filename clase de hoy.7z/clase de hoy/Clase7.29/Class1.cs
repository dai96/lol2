﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase7._29
{
    class Equipo
    {
        private short cantidadDeJugadores;
        private List<Jugador> jugadores;
        private string nombre;

        private Equipo()
        {
            this.jugadores = new List<Jugador>();
        }
        public Equipo(short cantidad, string nombre) : this()
        {
            this.cantidadDeJugadores = cantidad;
            this.nombre = nombre;
        }
        public static bool operator +(Equipo e, Jugador j)
        {
            if (e.jugadores.Count <= e.cantidadDeJugadores)
            {
                foreach (Jugador item in e.jugadores)
                {
                    if (item == j)
                    {
                        return false;
                    }
                }
            }

            e.jugadores.Add(j);

            return true;
        }

    }

    class Jugador
    {
        private int dni;
        private string nombre;
        private int partidosJugados;
        private float promedioGoles;
        private int totalGoles;

        public float GetPromedioGoles()
        {
            float promedio;
            if (this.partidosJugados != 0)
            {
                promedio = (float)this.totalGoles / (float)this.partidosJugados;
                this.promedioGoles = promedio;
            }

            return this.promedioGoles;
        }

        private Jugador()
        {
            this.dni = 0;
            this.nombre = null;
            this.partidosJugados = 0;
            this.promedioGoles = 0;
            this.totalGoles = 0;

        }
        public Jugador(int dni, string nombre) : this()
        {
            this.dni = dni;
            this.nombre = nombre;
        }
        public Jugador(int dni, string nomb, int totalGoles, int totalPartidos) : this(dni, nomb)
        {
            this.totalGoles = totalGoles;
            this.partidosJugados = totalPartidos;
        }
        public string MostrarDatos()
        {
            StringBuilder myStg = new StringBuilder();
            myStg.Append("\nJugador: " + this.nombre + " Dni: " + this.dni + "\nPartidos jugados: " + this.partidosJugados + " Promedio goles: " + this.GetPromedioGoles() + " Total de goles: " + this.totalGoles);
            return myStg.ToString();
        }
        public static bool operator ==(Jugador j1, Jugador j2)
        {
            if (j1.dni == j2.dni)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(Jugador j1, Jugador j2)
        {
            return !(j1 == j2);
        }

    }
}
