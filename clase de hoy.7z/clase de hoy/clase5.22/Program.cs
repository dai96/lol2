﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using clase5._22;

namespace clase5._22
{
    class Program
    {
            static void Main(string[] args)
            {
                double numero;
                string respuesta, aux;

                
                Console.WriteLine("Ingrese un numero binario: ");
                respuesta = Console.ReadLine();
                numero = Conversor.BinarioDecimal(respuesta);
                NumeroBinario bin = new NumeroBinario(respuesta);
                Console.WriteLine("{0}", numero);
                Console.WriteLine("Ingrese un numero decimal: ");
                aux = Console.ReadLine();
                double.TryParse(aux, out numero);
                NumeroDecimal deci = new NumeroDecimal(numero);
                respuesta = Conversor.DecimalBinario(numero);
                Console.WriteLine("{0}", respuesta);
                Console.WriteLine("La suma de los numero en decimal es de {0} y en binario{1}", deci + bin, bin + deci);

                Console.ReadKey();
            }
        
    }
}
