using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace clase7._26
{
  class Program
  {
    static void Main(string[] args)
    {
      Thread.Sleep(150);
      Random rdn = new Random();
      int []num;
      num = new int[19];
      for (int i = 0; i < num.Length; i++)
      {
        do
        {
          num[i] = rdn.Next(-100, 100);
        }
        while (num[i] == 0);
        Console.WriteLine("{0}", num[i]);
      }

      {


      }
        Console.ReadKey();


    }
  }
}
