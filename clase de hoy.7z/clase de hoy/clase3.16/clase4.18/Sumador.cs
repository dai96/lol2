using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase4._19
{
  class Sumador
  {
    private int cantidadSumas;

    public Sumador(int x)
    {
      this.cantidadSumas = x;
    }
    public Sumador() : this(0)
    {}

    public float Sumar (float a,float b)
    {
      this.cantidadSumas++;
      return a + b;
    }
    public string Sumar (string x, string y)
    {
      this.cantidadSumas++;
      return x + y;
    }

      public static explicit operator int(Sumador s)
        {
            return s.cantidadSumas;
        }

        public static bool operator |(Sumador a, Sumador b)
        {
            //bool rtn = false;
            //if (a.cantidadSumas==b.cantidadSumas)
            //  {
            //rtn = true;
            //}
            //return rtn;
            return (a.cantidadSumas == b.cantidadSumas);
        }

        public static long operator +(Sumador a, Sumador b)
        {
            long rtn;
            rtn = a.cantidadSumas+b.cantidadSumas;
            return rtn;
        }
  }
}
