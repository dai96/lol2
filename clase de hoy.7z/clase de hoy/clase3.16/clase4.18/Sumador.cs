using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase4._19
{
  class Sumador
  {
    private int cantidadSumas;

    public Sumador(int x)
    {
      this.cantidadSumas = x;
    }
    public Sumador() : this(0)
    {}

    public float Sumar (float a,float b)
    {
      this.cantidadSumas++;
      return a + b;
    }
    public string Sumar (string x, string y)
    {
      this.cantidadSumas++;
      return x + y;
    }
  }
}
