using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase4._19
{
  class Program
  {
    static void Main(string[] args)
    {
      float holi, prueba1, prueba2;
      Sumador suma = new Sumador(10);
      Sumador dossuma = new Sumador(8);
      holi = suma.Sumar(10, 5);
      prueba1=dossuma.Sumar(8, 7);//preguntar float aca      
      prueba2=dossuma.Sumar(7 , 3);                          
      Console.WriteLine("{0}", holi);
            Console.WriteLine("{0}", prueba1);
            Console.WriteLine("{0}", prueba2);
            Console.ReadKey();

            long sumadeambos;
            sumadeambos = suma + dossuma;
            if (!(suma | dossuma ))
            {
                Console.WriteLine("no son iguales");
            }
            Console.WriteLine("la suma de ambos es {0}", sumadeambos);
            Console.ReadKey();
        }
  }
}
