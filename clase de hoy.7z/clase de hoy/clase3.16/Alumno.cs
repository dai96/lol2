using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace clase3._16
{
  class Alumno
  {
    private byte nota1;
    private byte nota2;
    private float notaFinal;
    public string apellido;
    public int legajo;
    public string nombre;

    //Random rnd = new Random();

    public Alumno(string name, string surname, int leg)
    {
      this.apellido = surname;
      this.nombre = name;
      this.legajo = leg;
      //this.nota1 = 0;
      //this.nota2 = 0;
      //this.notaFinal = 0;
    }

    public void Estudiar(byte primerNota, byte segundaNota)
    {
      this.nota1 = primerNota;
      this.nota2 = segundaNota;

    }
    public void CalcularFinal()
    {
      Thread.Sleep(150);
      Random rdn = new Random();
      int nota;
      if (this.nota1 > 4 && this.nota2 > 4)
      {
        nota = rdn.Next(1,10);
        this.notaFinal = nota;
      }
      else
      {
        this.notaFinal = -1;

      }
    }

    public void Mostrar()
    {

      if (this.notaFinal!=-1)
      {
        Console.WriteLine("{0}  {1}  {2}  {3}  {4}  {5}", this.legajo, this.nombre, this.apellido, this.nota1, this.nota2,this.notaFinal);
      }
     else
      {
        Console.WriteLine("{0}  {1}  {2}  {3}  {4}  Alumno desaprobado", this.legajo, this.nombre, this.apellido, this.nota1, this.nota2);

      }

    }
    }
}
