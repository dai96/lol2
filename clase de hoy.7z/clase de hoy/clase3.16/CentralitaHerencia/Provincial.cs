using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
  class Provincial : Llamada
  {
    private Franja franjaHoraria;

    public enum Franja //podes dividir x 100
    {
      Franja_1,
      Franja_2,
      Franja_3
    }

    public Provincial(Franja miFranja, Llamada llamada): base(llamada.Duracion,llamada.NroDestino,llamada.NroOrigen)
    {
      
    }

    public Provincial (string ori, Franja miFranja, float dur, string dest):base(dur,dest,ori)
    {

    }

    private float CalcularCosto()
    {
      Franja.Franja_1 = 0.99f;
      Franja.Franja_2 = 1.25f;
      Franja.Franja_3 = 0.66f;
      float lala = 0.2f;
      return lala; 
     // if (franjaHoraria)
    }

    public override bool Equals(Object obj)
    {
      if (obj.GetType()==typeof(Provincial) // obj.is provincial
      {
        return true;
      }
      return false;
    }

    private new string Mostrar()
    {
      StringBuilder miStg = new StringBuilder();
      miStg.AppendLine(base.Mostrar() + " Costo:" + CalcularCosto + " Franja:" + franjaHoraria);
      return miStg.ToString();
    }

    public string ToString()
    {
      return Mostrar();
    }






  }
}
