using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    class Provincial : Llamada
    {
        private Franja franjaHoraria;

        public enum Franja //podes dividir x 100
        {
            Franja_1,
            Franja_2,
            Franja_3
        }
        public float CostoLlamada
        {
            get{ return this.CalcularCosto(); }
        }

        public Provincial(Franja miFranja, Llamada llamada) : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
        {
            this.franjaHoraria = miFranja;
        }

        public Provincial(string ori, Franja miFranja, float dur, string dest) : base(dur, dest, ori)
        {
            this.franjaHoraria = miFranja;
        }

        private float CalcularCosto()
        {
            float retorno = 0;
            switch (this.franjaHoraria)
            {
                case Franja.Franja_1:
                    retorno = (float)(this.Duracion * 0.99);
                    break;
                case Franja.Franja_2:
                    retorno = (float)(this.Duracion * 125);
                    break;
                case Franja.Franja_3:
                    retorno = (float)(this.Duracion * 0.66);
                    break;
                default:
                    break;
            }
            return retorno;
        }


        public override bool Equals(Object obj)
        {
            if (obj.GetType() == typeof(Provincial)) // obj.is provincial
            {
                return true;
            }
            return false;
        }

        private string Mostrar()
        {
            StringBuilder miStg = new StringBuilder();
            string hola = base.Mostrar();
            miStg.AppendLine(hola + " Costo:" + CalcularCosto() + " Franja:" + franjaHoraria);
            return miStg.ToString();
        }

        public override string ToString()
        {
            return Mostrar();
        }





    }
}
