using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
  class Centralita
  {
    private List<Llamada> listaDeLlamadas;
    protected string razonSocial;
       
        public float GananciasPorLocal
        {
            get { return this.CalcularGanancia(Llamada.TipoLlamada.Local);}
        }

        public float GananciasPorProvincia
        {
            get { return this.CalcularGanancia(Llamada.TipoLlamada.Provincial);}
        }

        public float GananciasPorTotal
        {
            get {return this.CalcularGanancia(Llamada.TipoLlamada.Todas); }
        }

        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }

        private float CalcularGanancia(Llamada.TipoLlamada llamadas)
        {
            float rtn = 0;
            float rtnTodos = 0;
            float rtnProv = 0;
            float rtnLocal =0;
            
            foreach (Llamada item in this.Llamadas)
            {
                if (item is Local)
                {
                  rtnTodos += rtnLocal += ((Local)item).CostoLlamada;
                }
                else if (item is Provincial)
                {
                    rtnTodos += rtnProv += ((Provincial)item).CostoLlamada;
                }
            }
            switch (llamadas)
            {
                case Llamada.TipoLlamada.Local:
                    rtn = rtnLocal;
                    break;
                case Llamada.TipoLlamada.Provincial:
                    rtn = rtnProv;
                    break;
                case Llamada.TipoLlamada.Todas:
                    rtn = rtnTodos;
                    break;
                default:
                    break;
            }
            return rtn;
        }

        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }
        public Centralita(string nombreEmpresa) : this()
        {
            this.razonSocial = nombreEmpresa;
        }
    
        
        public string Mostrar()
        {
            StringBuilder myStr = new StringBuilder();
            myStr.Append("\nRazon social: " + this.razonSocial + " Ganancia total: " + this.GananciasPorTotal + " Ganancia por llamadas locales: " + this.GananciasPorLocal + " Ganancia por llamadas provinciales: " + this.GananciasPorProvincia);
            myStr.AppendLine("\nDetalle de las llamadas: ");
            foreach (Llamada item in Llamadas)
            {
                if (item is Local)
                {
                    myStr.AppendLine(((Local)item).Mostrar());
                }
                else if (item is Provincial)
                {
                    myStr.AppendLine(((Provincial)item).Mostrar());
                }
            }
            return myStr.ToString();
        }
        public void OrdenarLlamadas()
        {
            this.Llamadas.Sort(Llamada.OrdenarPorDuracion);
        }
    }
}
