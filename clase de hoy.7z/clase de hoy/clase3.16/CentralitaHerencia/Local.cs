using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
 
    public class Local : Llamada
    {

      protected float costo;

      public float CostoLlamada
      {
        get { return CalcularCosto(); }
      }

      public Local(string ori, float dur, string dest, float cost) : base(dur, dest, ori)
      {
        this.costo = cost;
      }

      public Local(Llamada llamada, float cost) : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
      {
        this.costo = cost;
      }

      private float CalcularCosto()
      {
        return base.Duracion * this.costo;
      }
      public new string Mostrar()
      {

        StringBuilder miStg = new StringBuilder();
        miStg.AppendLine(base.Mostrar() + "Costo:" + CostoLlamada);
        return miStg.ToString();
      }


    }
  
}
