using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
  public class Llamada
  {
    protected float duracion;
    protected string nroDestino;
    protected string nroOrigen;

    public float Duracion
    {
      get { return duracion; }
    }
    public string NroDestino
    {
      get { return nroDestino; }
    }
    public string NroOrigen
    {
      get { return nroOrigen; }
    }

    public Llamada(float duracion, string nroDestino, string nroOrigen)
    {
      this.duracion = duracion;
      this.nroDestino = nroDestino;
      this.nroOrigen = nroOrigen;
    }

    public string Mostrar()
    {
      StringBuilder miStg = new StringBuilder();

      miStg.AppendLine("Duracion: " + Duracion + " Destino: " + NroDestino + " Origen: " + NroOrigen);

      return miStg.ToString();
    }

    public int OrdenarPorDuracion (Llamada llam1, Llamada llam2)
    {
      if (llam1.duracion>llam2.duracion)
      {
        return 1;
      }
      else if (llam1.duracion<llam2.duracion)
      {
        return -1;
      }
      return 0;
    }


    public enum TipoLlamada
    {
      Local,
      Provincial,
      Todas
    }

  }

  
}
