﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Euro
    {
        private double cantidad;
        private static double cotizRespectoDolar;

        #region Constructores
        public Euro(double cant, double cotizacion) : this(cant)
        {

            Euro.cotizRespectoDolar = cotizacion;
        }

        public Euro(double cant)
        {
            this.cantidad = cant;
        }

        static Euro()
        {
            Euro.cotizRespectoDolar = 1/1.3f;
        }
        
        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Euro.cotizRespectoDolar;
        }
        #endregion

        #region comparadores de cantidad
        public static implicit operator Euro(double d)
        {
            Euro aux = new Euro(d);
            return aux;
        }
        public static explicit operator Dolar(Euro p)
        {
            double nom;
            nom = p.cantidad / Euro.GetCotizacion();
            return new Dolar(nom);
        }

        public static explicit operator Pesos(Euro p)
        {
            return (Pesos)((Dolar)p); //NO LO ENTIENDO

        }

        public static bool operator ==(Euro p, Dolar d)
        {
            return p == (Euro)d;
        }
        public static bool operator !=(Euro p, Dolar d)
        {
            return !(p == d);
        }
        public static bool operator ==(Euro p, Pesos e)
        {
            return p == (Euro)e;
        }
        public static bool operator !=(Euro p, Pesos e)
        {
            return !(p == e);
        }
        public static bool operator ==(Euro p, Euro d)
        {
            return p.cantidad == d.cantidad;
        }
        public static bool operator !=(Euro p, Euro d)
        {
            return !(p == d);
        }


        public static Euro operator +(Euro e, Pesos p)
        {
            Euro aux = new Euro(e.cantidad + ((Euro)p).cantidad);
            return aux;
        }
        public static Euro operator +(Euro e, Dolar d)
        {
            Euro aux = new Euro(e.cantidad + ((Euro)d).cantidad);
            return aux;
        }

        public static Euro operator -(Euro p, Pesos e)
        {
            Euro aux = new Euro(p.cantidad - ((Euro)e).cantidad);
            return aux;
        }
        public static Euro operator -(Euro p, Dolar d)
        {
            Euro aux = new Euro(p.cantidad - ((Euro)d).cantidad);
            return aux;
        }

        #endregion
    }
}
