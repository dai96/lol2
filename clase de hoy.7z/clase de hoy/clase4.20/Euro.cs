﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    class Euro
    {
        private double cantidad;
        private static double cotizRespectoDolar;

        #region Constructores
        public Euro(double cant, double cotizacion) : this(cant)
        {

            Euro.cotizRespectoDolar = cotizacion;
        }

        public Euro(double cant)
        {
            this.cantidad = cant;
        }

        static Euro()
        {
            Euro.cotizRespectoDolar = 0.9;
        }
        #endregion
    }
}
