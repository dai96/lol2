using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Pesos
    {
        private double cantidad;
        private static double cotizRespectoDolar;//si pongo static acá los consturcciores que lo usen deben llevar pesos en lugar de this

        #region Constructores
        public Pesos(double cant, double cotizacion) : this(cant)
        {

            Pesos.cotizRespectoDolar = cotizacion;
        }

        public Pesos(double cant)
        {
            this.cantidad = cant;
        }

        private Pesos()
        {
            Pesos.cotizRespectoDolar = 59.40f;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Pesos.cotizRespectoDolar;
        }
        #endregion

        #region comparadores de cantidad
        public static implicit operator Pesos(double d)
        {
            Pesos aux = new Pesos(d);
            return aux;
        }
        public static explicit operator Dolar(Pesos p)
        {
            double nom;
            nom = p.cantidad / Pesos.GetCotizacion();
            return new Dolar(nom);
        }

        public static explicit operator Euro(Pesos p)
        {
            return (Euro)((Dolar)p); //NO LO ENTIENDO

        }

        public static bool operator ==(Pesos p, Dolar d)
        {
            return p == (Pesos)d;
        }
        public static bool operator !=(Pesos p, Dolar d)
        {
            return !(p == d);
        }
        public static bool operator ==(Pesos p, Euro e)
        {
            return p == (Pesos)e;
        }
        public static bool operator !=(Pesos p, Euro e)
        {
            return !(p == e);
        }
        public static bool operator ==(Pesos p, Pesos d)
        {
            return p.cantidad == d.cantidad;
        }
        public static bool operator !=(Pesos p, Pesos d)
        {
            return !(p == d);
        }


        public static Pesos operator +(Pesos p, Euro e)
        {
            Pesos aux = new Pesos(p.cantidad + ((Pesos)e).cantidad);
            return aux;
        }
        public static Pesos operator +(Pesos p, Dolar d)
        {
            Pesos aux = new Pesos(p.cantidad + ((Pesos)d).cantidad);
            return aux;
        }

        public static Pesos operator -(Pesos p, Euro e)
        {
            Pesos aux = new Pesos(p.cantidad - ((Pesos)e).cantidad);
            return aux;
        }

        public static Pesos operator -(Pesos p, Dolar d)
        {
            Pesos aux = new Pesos(p.cantidad - ((Pesos)d).cantidad);
            return aux;

        }

        #endregion
    }

}
