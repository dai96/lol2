using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
     public class Dolar
    {
        private double cantidad;
        private static double cotizRespectoDolar;

        #region Constructores
        public Dolar(double cant, double cotizacion) : this(cant)
        {

            Dolar.cotizRespectoDolar = cotizacion;
        }

        public Dolar(double cant)
        {
            this.cantidad = cant;
        }

        static Dolar()
        {
            Dolar.cotizRespectoDolar = 1;
        }
        
        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Dolar.cotizRespectoDolar;
        }
        #endregion

        #region comparadores de cantidad
        public static implicit operator Dolar(double d)
        {
            Dolar aux = new Dolar(d);
            return aux;
        }
        public static explicit operator Pesos(Dolar p)
        {
            double nom;
            nom = p.cantidad / Dolar.GetCotizacion();
            return new Pesos(nom);
        }

        public static explicit operator Euro(Dolar p)
        {
            double nom;
            nom = p.cantidad / Dolar.GetCotizacion();
            return new Euro(nom);

        }

        public static bool operator ==(Dolar p, Pesos d)
        {
            return p == (Dolar)d;
        }
        public static bool operator !=(Dolar p, Pesos d)
        {
            return !(p == d);
        }
        public static bool operator ==(Dolar p, Euro e)
        {
            return p == (Dolar)e;
        }
        public static bool operator !=(Dolar p, Euro e)
        {
            return !(p == e);
        }
        public static bool operator ==(Dolar d, Dolar p)
        {
            return p.cantidad == d.cantidad;
        }
        public static bool operator !=(Dolar p, Dolar d)
        {
            return !(p == d);
        }


        public static Dolar operator +(Dolar p, Euro e)
        {
            Dolar aux = new Dolar(p.cantidad + ((Dolar)e).cantidad);
            return aux;
        }
        public static Dolar operator +(Dolar p, Pesos d)
        {
            Dolar aux = new Dolar(p.cantidad + ((Dolar)d).cantidad);
            return aux;
        }

        public static Dolar operator -(Dolar p, Euro e)
        {
            Dolar aux = new Dolar(p.cantidad - ((Dolar)e).cantidad);
            return aux;
        }

        public static Dolar operator -(Dolar p, Pesos d)
        {
            Dolar aux = new Dolar(p.cantidad - ((Dolar)d).cantidad);
            return aux;
        }

        #endregion
    }
}
