﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    class Program
    {
        static void Main(string[] args)
        {
            Pesos peso;
            Dolar dolar;
            Euro euro;
            peso = new Pesos(1, 2.20);
            dolar = new Dolar(1, 1);
            euro = new Euro(2, 0.50);



            /*
             Cuestionario 2
             1-que es el paradigma orientado a objetos? que es un paradigma?
             1-define los programas en términos de comunidades de objetos........ Los objetos con características comunes se agrupan en clases, 
              son entidades que combinan un estado (es decir, datos) y un comportamiento (esto es, procedimientos o métodos). Estos objetos 
              se comunican entre ellos para realizar tareas
              Un paradigma es un modelo
            2-pilares=abstracion encapsulamiento herencia polimorfismo
            3-Que es una clase? Clasificacion en base a comportamientos y atributos comunes, es una abstracion del objeto
            4-Que es un objeto? en que se relaciona con su clase? Los objetos son entidades que combianan un estado o datos y un comportamiento (metodos)
            con características comunes se agrupan en clases 
            5-Que significa instanciar un objeto?
             
             
             
             
             
             
             */
        }
    }
}
