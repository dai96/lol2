using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Euro e = new Euro(10, 0.50f);
            Dolar d = new Dolar(10);
            Pesos p = new Pesos(10, 59.60f);
            */
            
            Euro e = new Euro(10, 0.809f);
            Dolar d = new Dolar(10);
            Pesos p = new Pesos(10, 20.1655f);
            
            Euro aux_e = e + d;
            Console.WriteLine("Euro + Dólar (€18,09xx): {0}", aux_e.GetCantidad());
            aux_e = e + p;
            Console.WriteLine("Euro + Pesos (€10,40xx): {0}", aux_e.GetCantidad());
            Console.WriteLine("----------------------------------------------");

            Dolar aux_d = d + e;
            Console.WriteLine("Dólar + Euro (U$S22,36xx): {0}", aux_d.GetCantidad());
            aux_d = d + p;
            Console.WriteLine("Dólar + Pesos (U$S10,49xx): {0}", aux_d.GetCantidad());
            Console.WriteLine("----------------------------------------------");

            Pesos aux_p = p + e;
            Console.WriteLine("Pesos + Euro ($259,26xx): {0}", aux_p.GetCantidad());
            aux_p = p + d;
            Console.WriteLine("Pesos + Dólar ($211,65xx): {0}", aux_p.GetCantidad());

            Console.ReadKey();


            /*
             Cuestionario 2
             1-que es el paradigma orientado a objetos? que es un paradigma?
             1-define los programas en términos de comunidades de objetos........ Los objetos con características comunes se agrupan en clases, 
              son entidades que combinan un estado (es decir, datos) y un comportamiento (esto es, procedimientos o métodos). Estos objetos 
              se comunican entre ellos para realizar tareas
              Un paradigma es un modelo
            2-pilares=abstracion encapsulamiento herencia polimorfismo
            3-Que es una clase? Clasificacion en base a comportamientos y atributos comunes, es una abstracion del objeto
            4-Que es un objeto? en que se relaciona con su clase? Los objetos son entidades que
            combianan un estado o datos
            y un comportamiento (metodos)
            con características comunes se agrupan en clases 
            5-Que significa instanciar un objeto?
             darle espacio en memoria a un objeto
             6-abtracion y relacion con clase
             permite tomar solo los objetos ultiles
             7- propiedades o caracteristicas de un objeto, donde van a almazanarce
             8-metodos: comportamiento
             18-que es un namespace: es una agrupacion de clases y otros objetos
             19: es posible pero no se recomienda
             20 directiva using= utilizar otro namespace a la nuesta;
             21: darle un numbre de fantasia a un namespace
             22=en el mismo no. en distinto si 
             
             de dos ejeplo de metodos estaticos.. math.pow();
             metodo de instancia random

              
             
             
             
             */
        }
    }
}
