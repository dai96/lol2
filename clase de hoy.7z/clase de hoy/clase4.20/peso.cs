﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    class Pesos
    {
        private double cantidad;
        private static double cotizRespectoDolar;//si pongo static acá los consturcciores que lo usen deben llevar pesos en lugar de this

        #region Constructores
        public Pesos(double cant, double cotizacion) : this(cant)
        {
       
            Pesos.cotizRespectoDolar = cotizacion;
        }

        public Pesos(double cant) 
        {
            this.cantidad = cant;
        }

        public Pesos()
        {
            Pesos.cotizRespectoDolar = 59.40f;
        }
        #endregion

        #region comparadores de cantidad

       /* public static bool operator !=(Pesos peso, Dolar dolar)
           {

            return (peso.cantidad == dolar.cantidad);
        }

        public static bool operator ==(Pesos peso, Dolar dolar)
           {

            return (peso.cantidad == dolar.cantidad);
           }*/
        #endregion
    }

}
