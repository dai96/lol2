﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase6._24
{
    #region Celcius
    class Celcius
    {

        public float temperatura;

        public Celcius(float temp)
        {
            this.temperatura = temp;
        }

        public float GetCantidad()
        {
            return this.temperatura;
        }

        public static explicit operator Fahrenheit(Celcius c)
        {

            float num = ((c.GetCantidad() * (9f / 5) )+ 32);
            Fahrenheit far = new Fahrenheit(num);
            return far;
        }
        public static explicit operator Kelvin(Celcius c)
        {
            Fahrenheit far = new Fahrenheit(0);
            far = (Fahrenheit)c;
            Kelvin kel = new Kelvin(0);
            kel = (Kelvin)far;
            return kel;
        }

        public static implicit operator Celcius(float c)
        {
            Celcius cel = new Celcius(c);
            return cel;
        }
    }
    #endregion

    #region fahrenheit
    class Fahrenheit
    {
        public float temperatura;

        public Fahrenheit(float temp)
        {
            this.temperatura = temp;
        }

        public float GetCantidad()
        {
            return this.temperatura;
        }

        public static explicit operator Celcius(Fahrenheit f)
        {
            float num;
            num = (f.GetCantidad() - 32) * 5 / 9f;
            Celcius c = new Celcius(num);
            return c;

        }

        public static explicit operator Kelvin(Fahrenheit f)
        {
            float num;
            num = (f.GetCantidad() + 459.67f) * 5 / 9f;
            Kelvin k = new Kelvin(num);
            return k;
        }

        public static implicit operator Fahrenheit(float f)
        {
            Fahrenheit far = new Fahrenheit(f);
            return far;
        }
    }
    #endregion

    #region Kelvin
    class Kelvin
    {
        public float temperatura;

        public Kelvin(float temp)
        {
            this.temperatura = temp;
        }

        public float GetCantidad()
        {
            return this.temperatura;
        }

        public static implicit operator Celcius(Kelvin k)
        {
            Fahrenheit far = new Fahrenheit(0);
            far = (Fahrenheit)k;
            Celcius c = new Celcius((far.GetCantidad() - 32) * 0.55f);
            return c;
        }

        public static implicit operator Fahrenheit(Kelvin k)
        {
            float num = (k.GetCantidad() * 1.8f) - 459.67f;
            Fahrenheit far = new Fahrenheit(num);
            return far;
        }

        public static explicit operator Kelvin(float k)
        {
            Kelvin kel = new Kelvin(k);
            return kel;

        }

    }
#endregion

}
