﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clase6._24
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            
            Fahrenheit far = new Fahrenheit(float.Parse(textBox1.Text));
            Celcius cel = new Celcius(0);
            Kelvin kel = new Kelvin(0);
            cel = (Celcius)far;
            kel = (Kelvin)far;
            textBox4.Text=(far.GetCantidad().ToString("N"));
            textBox5.Text=(cel.GetCantidad().ToString("N"));
            textBox6.Text=(kel.GetCantidad().ToString("N"));
        }

        private void Button2_Click(object sender, EventArgs e)
        {
           
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Fahrenheit far = new Fahrenheit(0);
            Celcius cel = new Celcius(0);
            Kelvin kel = new Kelvin(float.Parse(textBox3.Text));
            cel = (Celcius)kel;
            far = (Fahrenheit)kel;
            textBox10.Text = (far.GetCantidad().ToString("N"));
            textBox11.Text = (cel.GetCantidad().ToString("N"));
            textBox12.Text = (kel.GetCantidad().ToString("N"));
        }

        private void Button2_Click_1(object sender, EventArgs e)
        {
            Fahrenheit far = new Fahrenheit(0);
            Celcius cel = new Celcius(float.Parse(textBox2.Text));
            Kelvin kel = new Kelvin(0);
            far = (Fahrenheit)cel;
            kel = (Kelvin)cel;
            textBox7.Text = (far.GetCantidad().ToString("N"));
            textBox8.Text = (cel.GetCantidad().ToString("N"));
            textBox9.Text = (kel.GetCantidad().ToString("N"));
        }
    }
}
