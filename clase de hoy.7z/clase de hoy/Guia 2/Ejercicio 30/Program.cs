﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_30
{
    class Program
    {
        static void Main(string[] args)
        {
            bool algo = false;
            Competencia competencia = new Competencia(10, 5);
            AutoF1 a1 = new AutoF1(09, "Ferrari");
            AutoF1 a2 = new AutoF1(25, "Estudiar");
            AutoF1 a3 = new AutoF1(98, "Mucho");
            AutoF1 a4 = new AutoF1(12, "Cansa");
            AutoF1 a5 = new AutoF1(20, "Un");
            AutoF1 a6 = new AutoF1(35, "Monton");

            algo = competencia + a1;
            algo = competencia + a2;
            algo = competencia + a3;
            algo = competencia + a4;
            algo = competencia + a5;
            algo = competencia - a1;
            algo = competencia + a6;
            Console.WriteLine(competencia.MostrarDatos());
            Console.ReadLine();
        }
    }
}
