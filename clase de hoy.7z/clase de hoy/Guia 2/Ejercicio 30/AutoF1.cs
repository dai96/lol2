﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_30
{
    class AutoF1
    {
        private short cantidadCombustible;
        private bool enCompetencia;
        private string escuderia;
        private short numero;
        private short vueltasRestantes;

        public AutoF1(short numero, string escuderia)
        {
            this.cantidadCombustible = 0;
            this.enCompetencia = false;
            this.escuderia = escuderia;
            this.numero = numero;
            this.vueltasRestantes = 0;
        }
        public string MostrarDatos()
        {
            string competencia = "No está compitiendo";
            StringBuilder myStg = new StringBuilder();
            myStg.Append("\n\nNumero: " + this.numero + " Escuderia: " + this.escuderia);
            if (this.enCompetencia == true)
            {
                competencia = "Está compitiendo";
            }
            myStg.Append("\nEstado: " + competencia + " Vueltas restantes: " + this.vueltasRestantes + " Combustible disponible: " + this.cantidadCombustible);
            return myStg.ToString();

        }

        public static bool operator ==(AutoF1 a1, AutoF1 a2)
        {
            if (a1.numero == a2.numero && a1.escuderia == a2.escuderia)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(AutoF1 a1, AutoF1 a2)
        {
            return !(a1 == a2);
        }

    }
}
