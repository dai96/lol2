﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Ejercicio_30
{
    class Competencia
    {
        private short cantidadCompetidores;
        private short cantidadVueltas;
        private List<AutoF1> competidores;

        private Competencia()
        {
            this.competidores = new List<AutoF1>();
        }
        public Competencia(short cantidadVueltas, short cantidadCompetidores) : this()
        {
            this.cantidadVueltas = cantidadVueltas;
            this.cantidadCompetidores = cantidadCompetidores;
        }

        public string MostrarDatos()
        {
            StringBuilder myStg = new StringBuilder();
            myStg.Append("\ncantidad de Competidores: " + this.cantidadCompetidores + " Cantidad de vueltas: " + this.cantidadVueltas);
            foreach (AutoF1 item in this.competidores)
            {
                myStg.AppendFormat(item.MostrarDatos());
            }
            return myStg.ToString();
        }

        public static bool operator -(Competencia c, AutoF1 a)
        {
            if (c == a)
            {
                a.EnCompetencia = false;
                a.VueltasRestantes = 0;
                a.CantidadCombustible = 0;
                c.competidores.Remove(a);
                return true;
            }
            return false;
        }
        public static bool operator +(Competencia c, AutoF1 a)
        {
            Thread.Sleep(150);
            Random random = new Random();
            if (c.competidores.Count < c.cantidadCompetidores)
            {
                if (c != a)
                {
                    a.EnCompetencia = true;
                    a.VueltasRestantes = c.cantidadVueltas;
                    a.CantidadCombustible = (short)random.Next(15, 100);
                    c.competidores.Add(a);
                    return true;
                }
            }
            return false;
        }
        public static bool operator ==(Competencia c, AutoF1 a)
        {
            foreach (AutoF1 item in c.competidores)
            {
                if (item == a)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Competencia c, AutoF1 a)
        {
            return !(c == a);
        }
    }
}
