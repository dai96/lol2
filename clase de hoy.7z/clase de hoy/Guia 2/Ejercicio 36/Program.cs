﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_36
{
    class Program
    {
        static void Main(string[] args)
        {
            bool algo = false;
            Competencia competencia = new Competencia(10, 5, Competencia.TipoCompetencia.F1);
            AutoF1 a1 = new AutoF1(09, "Ferrari",100);
            AutoF1 a2 = new AutoF1(25, "Estudiar",200);
            AutoF1 a3 = new AutoF1(98, "Mucho",300);
            AutoF1 a4 = new AutoF1(12, "Cansa",400);
            AutoF1 a5 = new AutoF1(20, "Un",500);
            AutoF1 a6 = new AutoF1(35, "Monton",600);
            MotoCross m1 = new MotoCross(20, "BMW", 1000);
            algo = competencia + a1;
            algo = competencia + a2;
            algo = competencia + a3;
            algo = competencia + a4;
            algo = competencia + a5;
            algo = competencia - a1;
            algo = competencia + m1;
            algo = competencia + a6;
            Console.WriteLine(competencia.MostrarDatos());
            Console.ReadLine();
        }
    }
}
