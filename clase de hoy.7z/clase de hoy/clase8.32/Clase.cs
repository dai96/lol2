﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase8._32
{

    class Equipo
    {
        private short cantidadDeJugadores;
        private List<Jugador> jugadores;
        private string nombre;

        private Equipo()
        {
            this.jugadores = new List<Jugador>();
        }
        public Equipo(short cantidad, string nombre) : this()
        {
            this.cantidadDeJugadores = cantidad;
            this.nombre = nombre;
        }
        public static bool operator +(Equipo e, Jugador j)
        {
            if (e.jugadores.Count <= e.cantidadDeJugadores)
            {
                foreach (Jugador item in e.jugadores)
                {
                    if (item == j)
                    {
                        return false;
                    }
                }
            }

            e.jugadores.Add(j);

            return true;
        }

    }

    class Jugador
    {
        private int dni;
        private string nombre;
        private int partidosJugados;
        private int totalGoles;

        public int PartidosJugados
        {
            get { return this.partidosJugados; }
        }
        public float PromedioGoles
        {
            get
            {
                if (this.partidosJugados != 0)
                {
                    return (float)this.totalGoles / (float)this.partidosJugados;
                }
                return 0;
            }
        }
        public int TotalGoles
        {
            get { return this.totalGoles; }
        }
        public int Dni
        {
            get { return this.dni; }
            set { this.dni = value; }
        }
        public string Nombre
        {
            get { return this.nombre; }
            set { this.nombre = value; }
        }

        private Jugador()
        {
            this.dni = 0;
            this.nombre = null;
            this.partidosJugados = 0;
            this.totalGoles = 0;

        }
        public Jugador(int dni, string nombre) : this()
        {
            this.dni = dni;
            this.nombre = nombre;
        }
        public Jugador(int dni, string nomb, int totalGoles, int totalPartidos) : this(dni, nomb)
        {
            this.totalGoles = totalGoles;
            this.partidosJugados = totalPartidos;
        }
        public string MostrarDatos()
        {
            StringBuilder myStg = new StringBuilder();
            myStg.Append("\nJugador: " + this.nombre + " Dni: " + this.dni + "\nPartidos jugados: " + this.partidosJugados + " Promedio goles: " + PromedioGoles + " Total de goles: " + this.totalGoles);
            return myStg.ToString();
        }
        public static bool operator ==(Jugador j1, Jugador j2)
        {
            if (j1.dni == j2.dni)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(Jugador j1, Jugador j2)
        {
            return !(j1 == j2);
        }

    }
}
