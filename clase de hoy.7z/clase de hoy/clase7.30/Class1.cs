﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace clase7._30
{
    class Competencia
    {
        private short cantidadCompetidores;
        private short cantidadVueltas;
        private List<AutoF1> competidores;

        private Competencia ()
        {
            this.competidores = new List<AutoF1>();
        }
        public Competencia(short cantidadVueltas, short cantidadCompetidores) : this ()
        {
            this.cantidadVueltas = cantidadVueltas;
            this.cantidadCompetidores = cantidadCompetidores;
        }

        public string MostrarDatos ()
        {
            StringBuilder myStg = new StringBuilder();
            myStg.Append("\ncantidad de Competidores: " + this.cantidadCompetidores + " Cantidad de vueltas: " + this.cantidadVueltas);
            foreach (AutoF1 item in this.competidores)
            {
                myStg.AppendFormat(item.MostrarDatos());
            }
                return myStg.ToString();
        }

        public static bool operator -(Competencia c, AutoF1 a)
        {
            if (c == a)
            {
                a.EnCompetencia = false;
                a.VueltasRestantes = 0;
                a.CantidadCombustible = 0;
                c.competidores.Remove(a);
                return true;
            }
            return false;
        }
        public static bool operator +(Competencia c, AutoF1 a)
        {
            Thread.Sleep(150);
            Random random = new Random();
            if (c.competidores.Count< c.cantidadCompetidores)
            {
                if (c != a)
                {
                    a.EnCompetencia = true;
                    a.VueltasRestantes = c.cantidadVueltas;
                    a.CantidadCombustible = (short)random.Next(15, 100);
                    c.competidores.Add(a);
                    return true;
                }
            }
            return false;
        }
        public static bool operator ==(Competencia c, AutoF1 a)
        {
            foreach (AutoF1 item in c.competidores)
            {
                if (item == a)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Competencia c, AutoF1 a)
        {
            return !(c == a);
        }
    }

    class AutoF1
    {
        private short cantidadCombustible;
        private bool enCompetencia;
        private string escuderia;
        private short numero;
        private short vueltasRestantes;

        public AutoF1(short numero, string escuderia)
        {
            this.cantidadCombustible = 0;
            this.enCompetencia = false;
            this.escuderia = escuderia;
            this.numero = numero;
            this.vueltasRestantes = 0;
        }
        public  string MostrarDatos()
        {
            string competencia = "No está compitiendo";
            StringBuilder myStg = new StringBuilder();
            myStg.Append("\n\nNumero: " + this.numero + " Escuderia: " + this.escuderia);
            if (this.enCompetencia==true)
            {
                competencia = "Está compitiendo";
            }
            myStg.Append("\nEstado: " + competencia + " Vueltas restantes: " + this.vueltasRestantes + " Combustible disponible: " + this.cantidadCombustible);
            return myStg.ToString();

        }

        public static bool operator ==(AutoF1 a1, AutoF1 a2)
        {
            if (a1.numero == a2.numero && a1.escuderia == a2.escuderia)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(AutoF1 a1, AutoF1 a2)
        {
            return !(a1 == a2);
        }

        public short CantidadCombustible
            {
            get { return this.cantidadCombustible; }
            set { this.cantidadCombustible = value; }
            }
        public bool EnCompetencia
        {
            get { return this.enCompetencia;}
            set { this.enCompetencia = value; }
        }
        public short VueltasRestantes
        {
            get { return this.vueltasRestantes; }
            set { this.vueltasRestantes = value; }
        }
    }
}
