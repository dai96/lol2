using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_5
{
  class Estante
  {
    private Producto[] productos;
    private int ubicacionEstante;

    private Estante(int capacidad)
    {
      this.productos = new Producto[capacidad];
    }

    public Estante(int capacidad, int ubicacion) : this(capacidad)
      {
      this.ubicacionEstante = ubicacion;
      }

    public Producto[] GetProducto ()
    { 
      return this.productos;
    }

    public static string MostrarEstante(Estante e)
    {
      StringBuilder miSb = new StringBuilder();

      int i;
      for (i=0;i<e.productos.Length;i++)
      {
        if (!(e.productos[i] is null))
        {
          miSb.AppendLine("Estante: " + i + " " + Producto.MostrarProducto(e.productos[i]));
        }
      }
      return miSb.ToString();
    }

    public static bool operator ==(Estante a, Producto b)
    {
      int i;
      for (i=0;i<a.productos.Length;i++)
      {
        if (!(a.productos[i] is null))
        {
          if (b == a.productos[i])
          {
            return true;
          }
        }
       
      }

      return false;
    }

    public static bool operator !=(Estante a, Producto b)
    {
      return !(a == b);
    }

    public static bool operator +(Estante e, Producto b)
    {
      int i;
      for (i=0;i<e.productos.Length;i++)
      {
        if (e.productos[i]==b)
        {
          break;
        }
        if (e.productos[i] is null)
        {
          e.productos[i] = b;
          return true;
        }
      }
      
      return false;

    }

    public static Estante operator - (Estante e, Producto b)
    {
      
      int i;
      for (i=0;i<e.productos.Length;i++)
      {
        if (e.productos[i]==b)
        {
          e.productos[i] = null;
          return e;
        }
        
      }
      return e;
    }
  }
}
