﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_5
{
        class Producto
        {
            private string codigoDeBarra;
            private string marca;
            private float precio;

            public Producto(string marca, string codigo, float precio)
            {
                this.codigoDeBarra = codigo;
                this.marca = marca;
                this.precio = precio;

            }



            public string GetMarca()
            {
                return this.marca;
            }
            public string GetPrecio()
            {
            return string.Format("", this.precio);
            }
        
        public static string MostrarProducto(Producto p)
        {
            StringBuilder miStg = new StringBuilder();

            miStg.AppendLine("Producto: " + p.marca + "Precio: " + p.precio + "Cod:" + p.codigoDeBarra );

            return miStg.ToString();
        }
          

        public static explicit operator string(Producto p)
        {
            return p.codigoDeBarra;
        }
        public static bool operator ==(Producto a, Producto b)
        {
            if (a.marca == b.marca && a.codigoDeBarra == b.codigoDeBarra)
            {
                return true;
            }
            return false;

        }
        public static bool operator !=(Producto a, Producto b)
        {
            
            return !(a==b);

        }

        public static bool operator ==(Producto p, string marca)
        {
            if (p.marca==marca)
            {
                return true;
            }
            return false;
        }

        public static bool operator !=(Producto p, string marca)
        {
            return !(p == marca);

        }

    }
    
}
