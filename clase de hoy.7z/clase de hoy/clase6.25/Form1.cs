using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clase6._25
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
      // float a = 1;
      // NumeroDecimal n = 10; TENGO QUE USARLO ASI EL CONSTRUCTOR PRIVADO 
      NumeroBinario b = textBox1.Text; // new NumeroBinario(textBox1.Text);
            double num= Conversor.BinarioDecimal(b.numero);
            textBox3.Text = num.ToString();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            NumeroDecimal d = (double.Parse(textBox2.Text));
            textBox4.Text= Conversor.DecimalBinario(d.numero);


        }
    }
}
