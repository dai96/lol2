using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase6._25
{
    public static class Conversor
    {


        public static string DecimalBinario(double x)
        {
            string cadena = "hola";

            if (x > 0)
            {
                cadena = "";
                while (x > 0)
                {
                    if (x % 2 == 0)
                    {
                        cadena = "0" + cadena;

                    }
                    else
                    {
                        cadena = "1" + cadena;

                    }
                    x = (int)x / 2;
                }
                return cadena;
            }

            return cadena;
        }
        public static double BinarioDecimal(string x)
        {
            int l = x.Length;
            int i;
            double resp = 0;

            for (i = 1; i <= l; i++)
            {

                byte n = byte.Parse(x.Substring(l - i, 1));
                if (n == 1)
                    resp += System.Math.Pow(2, i - 1);
            }
            return resp;
        }

    }

    public class NumeroBinario
    {
        public string numero;

        private NumeroBinario(string num)
        {
            this.numero = num;
        }

        public static string operator +(NumeroBinario b, NumeroDecimal d)
        {
            double bin = Conversor.BinarioDecimal(b.numero);
            bin = bin + d.numero;
            return Conversor.DecimalBinario(bin);
        }

        public static string operator -(NumeroBinario b, NumeroDecimal d)
        {
            double bin = Conversor.BinarioDecimal(b.numero);
            bin = bin - d.numero;
            return Conversor.DecimalBinario(bin);
        }
        public static bool operator ==(NumeroBinario b, NumeroDecimal d)
        {
            double bin = Conversor.BinarioDecimal(b.numero);
            if (bin == d.numero)
            {
                return true;
            }
            return false;
        }

        public static bool operator !=(NumeroBinario b, NumeroDecimal d)
        {
            return !(b == d);
        }

        public static implicit operator NumeroBinario(string numero)
        {
            NumeroBinario nb = new NumeroBinario(numero);
            return nb;
        }

        public static explicit operator string(NumeroBinario nb)
        {
            return nb.numero;
        }
    }


    public class NumeroDecimal
    {
        public double numero;

    private NumeroDecimal(double num)//SI PONIA EN PRIVATE NO PODIA SEGUIR EN EL MAIN
        {
            this.numero = num;
        }

        public static double operator +(NumeroDecimal d, NumeroBinario b)
        {
            double bin = Conversor.BinarioDecimal(b.numero);
            bin = bin + d.numero;
            return bin;
        }

        public static double operator -(NumeroDecimal d, NumeroBinario b)
        {
            double bin = Conversor.BinarioDecimal(b.numero);
            bin = d.numero - bin;
            return bin;
        }

        public static bool operator ==(NumeroDecimal d, NumeroBinario b)
        {
            double bin = Conversor.BinarioDecimal(b.numero);
            if (bin == d.numero)
            {
                return true;
            }
            return false;
        }

        public static bool operator !=(NumeroDecimal d, NumeroBinario b)
        {
            return !(b == d);
        }

        public static implicit operator NumeroDecimal(double numero)
        {
            NumeroDecimal nd = new NumeroDecimal(numero);
            return nd;
        }

        public static explicit operator double(NumeroDecimal nd)
        {
            return nd.numero;
        }
    }
}
