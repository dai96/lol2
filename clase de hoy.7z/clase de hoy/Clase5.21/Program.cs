﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase5._21
{
    class Program
    {
        static void Main(string[] args)
        {

            Celcius c = new Celcius(2.3f);
            Console.WriteLine("{0}", c.GetCantidad());

            Console.ReadKey();
        }
    }
}
