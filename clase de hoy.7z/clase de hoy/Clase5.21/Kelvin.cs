﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase5._21
{
    class Kelvin
    {
        public float temperatura;

        public Kelvin(float temp)
        {
            this.temperatura = temp;
        }

        public float GetCantidad()
        {
            return this.temperatura;
        }

        public static implicit operator Celcius(Kelvin k)
        {
            Fahrenheit far = new Fahrenheit(0);
            far = (Fahrenheit)k;
            Celcius c = new Celcius((far.GetCantidad() - 32) * 0.55f);
            return c;
        }

        public static implicit operator Fahrenheit(Kelvin k)
        {
            float num = (k.GetCantidad() * 1.8f) - 459.67f;
            Fahrenheit far = new Fahrenheit(num);
            return far;
        }

        public static explicit operator Kelvin(float k)
        {
            Kelvin kel = new Kelvin (k);
            return kel;

        }

      }



}