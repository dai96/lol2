﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase5._21
{
    class Fahrenheit
    {
        public float temperatura;

        public Fahrenheit(float temp)
        {
            this.temperatura = temp;
        }

        public float GetCantidad()
        {
            return this.temperatura;
        }

        public static explicit operator Celcius(Fahrenheit f)
        {
            float num;
            num = (f.GetCantidad() - 32) * 5 / 9f;
            Celcius c = new Celcius(num);
            return c;

        }

        public static explicit operator Kelvin(Fahrenheit f)
        {
            float num;
            num = (f.GetCantidad() + 459.67f) * 5 / 9f;
            Kelvin k = new Kelvin(num);
            return k;
        }

        public static implicit operator Fahrenheit(float f)
        {
            Fahrenheit far = new Fahrenheit(f);
            return far;
        }
    }
}
