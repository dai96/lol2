﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase5._21
{
    class Celcius
    {

        public float temperatura;

        public Celcius(float temp)
        {
            this.temperatura = temp;
        }

        public float GetCantidad()
        {
            return this.temperatura;
        }

        public static explicit operator Fahrenheit(Celcius c)
        {
           
           float num = c.GetCantidad() * ((9 / 5f) + 32);
            Fahrenheit far = new Fahrenheit(num);
            return far;
        }
        public static explicit operator Kelvin(Celcius c)
        {
            Fahrenheit far = new Fahrenheit(0);
            far = (Fahrenheit)c;
            Kelvin kel = new Kelvin(0);
            kel = (Kelvin)far;
            return kel;
        }

        public static implicit operator Celcius(float c)
        {
            Celcius cel = new Celcius(c);
            return cel;
        }
    }
}
