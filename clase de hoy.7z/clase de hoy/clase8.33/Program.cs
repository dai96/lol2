﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase8._33
{
    class Program
    {
        static void Main(string[] args)
        {
            Libro libro = new Libro();
            libro[0] = "Hola que tal";
            libro[1] = "Como estas";
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine(libro[i]);
            }
            libro[0] = "Empecemos otra vez";
            libro[1] = "Nueva pag";
            libro[2] = "lol";
            libro[3] = "we";
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine(libro[i]);
            }
            Console.ReadLine();

        }
    }

    class Libro
    {
        private List<string> paginas;
        public Libro()
        {
            this.paginas = new List<string>();
        }
        public string this[int i]
        {
            get
            {
                if (i >= 0 && i < this.paginas.Count)
                {
                    return paginas[i];
                }
                return "lolno";

            }
            set
            {
                if(i>this.paginas.Count)
                {
                    this.paginas.Add(value);
                }
                else if (i>=0)
                {
                    this.paginas.Insert(i, value);
                }


            }
        }
    }

}
