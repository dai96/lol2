using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CosasBoli
{
  class Boligrafo
  {
    public const short cantidadTintaMaxima = 100;
    private ConsoleColor color;
    private short tinta;

    public Boligrafo(short tint, ConsoleColor col)
      {
      this.color = col;

      this.tinta = tint;
      }

    public ConsoleColor GetColor()
    {
      return this.color;
    }

    public short GetTinta()
    {

      return this.tinta;
    }

    private void SetTinta(short tin)
    {
      if (this.tinta<cantidadTintaMaxima)
      {
        if (tin>0)
        {
          this.tinta = (short)(this.tinta + tin);
        }
        if (tin<0)
        {
          this.tinta =(short)(this.tinta - tin);
        }
      }
    }

    public void Recargar()
    {
      this.tinta = cantidadTintaMaxima;
    }

    public bool Pintar (short gasto, out string dibujo)
    {
      this.SetTinta(gasto);
      dibujo="1";
      if (gasto<50)
      {
        dibujo = "*";
        return true;
      }
      if (gasto>50)
        {
        dibujo = "**";
          return true;
        }

      dibujo = "0";
      return false;
      
    }
  }
}
