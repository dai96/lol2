using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
  class Producto
  {
    private string codigoDeBarra;
    private string marca;
    private float precio;

    public Producto (string marca, string codigo, float precio)
    {
      this.codigoDeBarra = codigo;
      this.marca = marca;
      this.precio = precio;

    }

   

    public string GetMarca()
    {
      return this.marca;
    }
    public string GetPrecio()
    {
      return this.precio;
    }

  }
}
