using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase4._19
{
  class Program
  {
    static void Main(string[] args)
    {
      float holi;
      Sumador suma = new Sumador(10);
      holi = suma.Sumar(10, 5);
      Console.WriteLine("{0}", holi);
      Console.ReadKey();
    }
  }
}
