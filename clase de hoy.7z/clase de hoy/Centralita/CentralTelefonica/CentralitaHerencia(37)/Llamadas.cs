﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CentralitaHerencia_37_
{
    public class Llamadas
    {
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;

        public float Duracion
        {
            get { return this.duracion; }
        }
        public string NroDestino
        {
            get { return this.nroDestino; }
        }
        public string NroOrigen
        {
            get { return this.nroOrigen; }
        }

        public Llamadas(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }

        public string Mostrar()
        {
            StringBuilder miStg = new StringBuilder();

            miStg.AppendLine("\nDuracion: " + Duracion + "\nDestino: " + NroDestino + "\nOrigen: " + NroOrigen);

            return miStg.ToString();
        }

        public static int OrdenarPorDuracion(Llamadas llam1, Llamadas llam2)
        {
            if (llam1.duracion > llam2.duracion)
            {
                return 1;
            }
            else if (llam1.duracion < llam2.duracion)
            {
                return -1;
            }
            return 0;
        }

        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }
    }
}
