﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia_37_
{
    public class Centralita
    {
        private List<Llamadas> listaDeLlamadas;
        protected string razonSocial;
        public float GananciasPorLocal
        {
            get { return this.CalcularGanancia(Llamadas.TipoLlamada.Local); }
        }

        public float GananciasPorProvincia
        {
            get { return this.CalcularGanancia(Llamadas.TipoLlamada.Provincial); }
        }

        public float GananciasPorTotal
        {
            get { return this.CalcularGanancia(Llamadas.TipoLlamada.Todas); }
        }

        public List<Llamadas> Llamada
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }

        private float CalcularGanancia(Llamadas.TipoLlamada llamadas)
        {
            float rtn = 0;
            float rtnTodos = 0;
            float rtnProv = 0;
            float rtnLocal = 0;

            foreach (Llamadas item in this.Llamada)
            {
                if (item is Local)
                {
                    rtnTodos += rtnLocal += ((Local)item).CostoLlamada;
                }
                else if (item is Provincial)
                {
                    rtnTodos += rtnProv += ((Provincial)item).CostoLlamada;
                }
            }
            switch (llamadas)
            {
                case Llamadas.TipoLlamada.Local:
                    rtn = rtnLocal;
                    break;
                case Llamadas.TipoLlamada.Provincial:
                    rtn = rtnProv;
                    break;
                case Llamadas.TipoLlamada.Todas:
                    rtn = rtnTodos;
                    break;
                default:
                    break;
            }
            return rtn;
        }

        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamadas>();
        }
        public Centralita(string nombreEmpresa) : this()
        {
            this.razonSocial = nombreEmpresa;
        }


        public string Mostrar()
        {
            StringBuilder myStr = new StringBuilder();
            myStr.Append("\nRazon social: " + this.razonSocial + " Ganancia total: " + this.GananciasPorTotal + " Ganancia por llamadas locales: " + this.GananciasPorLocal + " Ganancia por llamadas provinciales: " + this.GananciasPorProvincia);
            myStr.AppendLine("\nDetalle de las llamadas: ");
            foreach (Llamadas item in Llamada)
            {
                if (item is Local)
                {
                    myStr.AppendLine(((Local)item).Mostrar());
                }
                else if (item is Provincial)
                {
                    myStr.AppendLine(((Provincial)item).Mostrar());
                }
            }
            return myStr.ToString();
        }
        public void OrdenarLlamadas()
        {
            this.Llamada.Sort(Llamadas.OrdenarPorDuracion);
        }
    }
}
