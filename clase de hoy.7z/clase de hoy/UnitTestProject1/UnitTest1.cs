using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using clase10._40;

namespace UnitTestProject1
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void testCent()
    {
      Centralita c = new Centralita("lol");
      Centralita aux = new Centralita("aux");

      Assert.IsNotNull(c);
      Assert.IsNotNull(aux);

    }
    [TestMethod]
    public void testLocal()
    {
      //arrange
      Centralita c = new Centralita("Fede Center");
      Local l1 = new Local("Bernal", 30, "Rosario", 2.65f);
      Local l2 = new Local("Bernal", 30, "Rosario", 2.65f);
      //act
      try
      {
        c += l1;
        c += l2;
      }
      catch (Exception e)
      {
        Assert.IsInstanceOfType(e, typeof(CentralitaException));
      }

      //assert

    }
    [TestMethod]
    [ExpectedException(typeof(CentralitaException)]
    public void testProv()
    {
      //arrange
      Centralita c = new Centralita("Fede Center");
      Provincial p1 = new Provincial("Bernal", Provincial.Franja.Franja_1,  2.65f, "rosario");
      Provincial p2 = new Provincial("Bernal", Provincial.Franja.Franja_1, 2.65f, "rosario");

      //act
      try
      {
        c += p1;
        c += p2;

      }
      catch (Exception e)
      {
        Assert.IsInstanceOfType(e, typeof(CentralitaException));
      }

      //assert

    }

  }
}


/*
  // Mi central 
            Centralita c = new Centralita("Fede Center");

            // Mis 4 llamadas 
            Local l1 = new Local("Bernal", 30, "Rosario", 2.65f);
            Provincial l2 = new Provincial("Morón", Provincial.Franja.Franja_1, 21, "Bernal");
            Local l3 = new Local("Lanús", 45, "San Rafael", 1.99f);
            Provincial l4 = new Provincial(Provincial.Franja.Franja_3, l2);

            // Las llamadas se irán registrando en la Centralita. 
            // La centralita mostrará por pantalla todas las llamadas según las vaya registrando.
            c.Llamadas.Add(l1);
            Console.WriteLine(c.Mostrar());
            c.Llamadas.Add(l2);
            Console.WriteLine(c.Mostrar());
            c.Llamadas.Add(l3);
            Console.WriteLine(c.Mostrar());
            c.Llamadas.Add(l4);
            Console.WriteLine(c.Mostrar());

            c.OrdenarLlamadas();
           Console.WriteLine(c.Mostrar());

            Console.ReadKey();
 */
