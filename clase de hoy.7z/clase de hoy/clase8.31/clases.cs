using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace clase8._31
{
  class Cliente
  {
    private string nombre;
    private int numero;

    public string Nombre //esto tiene que estar siempr eb public
    {
      get { return nombre; }
      set { nombre = value; }
    }
    private int Numero
    {
      get { return numero; }
    }
    public Cliente(int numero)
    {
      this.numero = numero;
    }
    public Cliente(int numero, string nombre) : this(numero)
    {
      this.nombre = nombre;
    }

    public static explicit bool operator ==(Cliente c1, Cliente c2)
      {



      }
  }
  class Negocio
  {

  }
  public class PuestoAtencion
  {
    private static int numeroActual;
    private Puesto puesto;

    private static int NumeroActual
    {
      get { return numeroActual+1; }
    }

    public bool Atender(Cliente cli)
    {


    }

    private PuestoAtencion ()
    {
      PuestoAtencion.numeroActual = 0;
    }

    public PuestoAtencion(Puesto puesto)
    { }


  }

}

  
  //explicito conciente
    //implicito solo 

