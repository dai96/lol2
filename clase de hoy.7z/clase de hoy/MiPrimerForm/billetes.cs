﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiPrimerForm
{

   
        #region dolar
        public class Dolar
        {
            private double cantidad;
            private static double cotizRespectoDolar;

            #region Constructores
            public Dolar(double cant, double cotizacion) : this(cant)
            {

                Dolar.cotizRespectoDolar = cotizacion;
            }

            public Dolar(double cant) : this()
            {
                this.cantidad = cant;
            }

            private Dolar()
            {
            this.cantidad = 0;
                Dolar.cotizRespectoDolar = 1;
            }

            public double GetCantidad()
            {
                return this.cantidad;
            }

            public static double GetCotizacion()
            {
                return Dolar.cotizRespectoDolar;
            }
            #endregion

            #region comparadores de cantidad
            public static implicit operator Dolar(double d)
            {
                Dolar aux = new Dolar(d);
                return aux;
            }
            public static explicit operator Pesos(Dolar p)
            {
                double nom;
                nom = p.cantidad * Pesos.GetCotizacion();
                return new Pesos(nom);
            }

            public static explicit operator Euro(Dolar p)
            {
                double nom;
                nom = p.cantidad / Euro.GetCotizacion();
                return new Euro(nom);

            }

            public static bool operator ==(Dolar p, Pesos d)
            {
                return p == (Dolar)d;
            }
            public static bool operator !=(Dolar p, Pesos d)
            {
                return !(p == d);
            }
            public static bool operator ==(Dolar p, Euro e)
            {
                return p == (Dolar)e;
            }
            public static bool operator !=(Dolar p, Euro e)
            {
                return !(p == e);
            }
            public static bool operator ==(Dolar d, Dolar p)
            {
                return p.cantidad == d.cantidad;
            }
            public static bool operator !=(Dolar p, Dolar d)
            {
                return !(p == d);
            }


            public static Dolar operator +(Dolar p, Euro e)
            {
                Dolar aux = new Dolar(p.cantidad + ((Dolar)e).cantidad);
                return aux;
            }
            public static Dolar operator +(Dolar p, Pesos d)
            {
                Dolar aux = new Dolar(p.cantidad + ((Dolar)d).cantidad);
                return aux;
            }

            public static Dolar operator -(Dolar p, Euro e)
            {
                Dolar aux = new Dolar(p.cantidad - ((Dolar)e).cantidad);
                return aux;
            }

            public static Dolar operator -(Dolar p, Pesos d)
            {
                Dolar aux = new Dolar(p.cantidad - ((Dolar)d).cantidad);
                return aux;
            }

            #endregion
        }


        #endregion

        #region euro
        public class Euro
        {
            private double cantidad;
            private static double cotizRespectoDolar;

            #region Constructores
            public Euro(double cant, double cotizacion) : this(cant)
            {

                Euro.cotizRespectoDolar = cotizacion;
            }

            public Euro(double cant) : this()
            {
                this.cantidad = cant;
            }

            private Euro()
            {
                this.cantidad = 0;
                Euro.cotizRespectoDolar = 1.3f;
            }

            public double GetCantidad()
            {
                return this.cantidad;
            }

            public static double GetCotizacion()
            {
                return Euro.cotizRespectoDolar;
            }
            #endregion

            #region comparadores de cantidad
            public static implicit operator Euro(double d)
            {
                Euro aux = new Euro(d);
                return aux;
            }
            public static explicit operator Dolar(Euro p)
            {
                double nom;
                nom = p.cantidad * Euro.GetCotizacion();
                return new Dolar(nom);
            }

            public static explicit operator Pesos(Euro p)
            {
                Dolar dolar = new Dolar(0);
                dolar = (Dolar)p;
                Pesos peso = new Pesos(dolar.GetCantidad() * Pesos.GetCotizacion());
                return peso;

            }

            public static bool operator ==(Euro p, Dolar d)
            {
                return p == (Euro)d;
            }
            public static bool operator !=(Euro p, Dolar d)
            {
                return !(p == d);
            }
            public static bool operator ==(Euro p, Pesos e)
            {
                return p == (Euro)e;
            }
            public static bool operator !=(Euro p, Pesos e)
            {
                return !(p == e);
            }
            public static bool operator ==(Euro p, Euro d)
            {
                return p.cantidad == d.cantidad;
            }
            public static bool operator !=(Euro p, Euro d)
            {
                return !(p == d);
            }


            public static Euro operator +(Euro e, Pesos p)
            {
                Euro aux = new Euro(e.cantidad + ((Euro)p).cantidad);
                return aux;
            }
            public static Euro operator +(Euro e, Dolar d)
            {
                Euro aux = new Euro(e.cantidad + ((Euro)d).cantidad);
                return aux;
            }

            public static Euro operator -(Euro p, Pesos e)
            {
                Euro aux = new Euro(p.cantidad - ((Euro)e).cantidad);
                return aux;
            }
            public static Euro operator -(Euro p, Dolar d)
            {
                Euro aux = new Euro(p.cantidad - ((Euro)d).cantidad);
                return aux;
            }

            #endregion
        }
        #endregion

         #region  pesos
        public class Pesos
        {
            private double cantidad;
            private static double cotizRespectoDolar;//si pongo static acá los consturcciores que lo usen deben llevar pesos en lugar de this

            #region Constructores
            public Pesos(double cant, double cotizacion) : this(cant)
            {

                Pesos.cotizRespectoDolar = cotizacion;
            }

        public Pesos(double cant) : this()
            {
                this.cantidad = cant;
            }

            private Pesos()
            {
            this.cantidad = 0;
                Pesos.cotizRespectoDolar = 59.40f;
            }

            public double GetCantidad()
            {
                return this.cantidad;
            }

            public static double GetCotizacion()
            {
                return Pesos.cotizRespectoDolar;
            }
            #endregion

            #region comparadores de cantidad
            public static implicit operator Pesos(double d)
            {
                Pesos aux = new Pesos(d);
                return aux;
            }
            public static explicit operator Dolar(Pesos p)
            {
                double nom;
                nom = p.cantidad / Pesos.GetCotizacion();
                return new Dolar(nom);
            }

            public static explicit operator Euro(Pesos p)
            {
                Dolar dolar = new Dolar(0);
                dolar = (Dolar)p;
                Euro euro = new Euro(dolar.GetCantidad() * Euro.GetCotizacion());
                return euro;
            }

            public static bool operator ==(Pesos p, Dolar d)
            {
                return p == (Pesos)d;
            }
            public static bool operator !=(Pesos p, Dolar d)
            {
                return !(p == d);
            }
            public static bool operator ==(Pesos p, Euro e)
            {
                return p == (Pesos)e;
            }
            public static bool operator !=(Pesos p, Euro e)
            {
                return !(p == e);
            }
            public static bool operator ==(Pesos p, Pesos d)
            {
                return p.cantidad == d.cantidad;
            }
            public static bool operator !=(Pesos p, Pesos d)
            {
                return !(p == d);
            }


            public static Pesos operator +(Pesos p, Euro e)
            {
                Pesos aux = new Pesos(p.cantidad + ((Pesos)e).cantidad);
                return aux;
            }
            public static Pesos operator +(Pesos p, Dolar d)
            {
                Pesos aux = new Pesos(p.cantidad + ((Pesos)d).cantidad);
                return aux;
            }

            public static Pesos operator -(Pesos p, Euro e)
            {
                Pesos aux = new Pesos(p.cantidad - ((Pesos)e).cantidad);
                return aux;
            }

            public static Pesos operator -(Pesos p, Dolar d)
            {
                Pesos aux = new Pesos(p.cantidad - ((Pesos)d).cantidad);
                return aux;

            }

            #endregion
        }

        #endregion pesos
    }


