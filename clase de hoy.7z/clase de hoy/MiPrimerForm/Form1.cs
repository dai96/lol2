using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiPrimerForm
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void richTextBox1_TextChanged(object sender, EventArgs e)
    {
            
    }

    private void label1_Click(object sender, EventArgs e)
    {

    }

    private void label3_Click(object sender, EventArgs e)
    {

    }

    private void label5_Click(object sender, EventArgs e)
    {

    }

    private void label7_Click(object sender, EventArgs e)
    {

    }

    private void label6_Click(object sender, EventArgs e)
    {

    }

    private void textBox11_TextChanged(object sender, EventArgs e)
    {

    }

    private void Form1_Load(object sender, EventArgs e)
    {
            Euro euro = new Euro(0);
            Pesos peso = new Pesos(0);
            Dolar dolar = new Dolar(0);
            
        }

        private void TextBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Euro euro = new Euro(double.Parse(textBox14.Text));
            Pesos peso = new Pesos(0);
            Dolar dolar = new Dolar(0);
            Euro aux = new Euro(0);
            aux = euro;
            peso = (Pesos)euro;
            dolar = (Dolar)euro;
            textBox3.Text = (aux.GetCantidad()).ToString("N");
            textBox6.Text = (dolar.GetCantidad()).ToString("N");
            textBox9.Text = (peso.GetCantidad()).ToString("N");
        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Dolar dolar = new Dolar(double.Parse(textBox13.Text));
            Pesos peso = new Pesos(0);
            Euro euro = new Euro(0);
            Dolar aux = new Dolar(0);
            aux = dolar;
            peso = (Pesos)dolar;
            euro = (Euro)dolar;
            textBox2.Text = (euro.GetCantidad()).ToString("N");
            textBox5.Text = (aux.GetCantidad()).ToString("N");
            textBox8.Text = (peso.GetCantidad()).ToString("N");

        }

        private void TextBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox15_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Pesos peso = new Pesos(double.Parse(textBox15.Text));
            Dolar dolar = new Dolar(0);
            Euro euro = new Euro(0);
            Pesos aux = new Pesos(0);
            aux = peso;
            dolar = (Dolar)peso;
            euro = (Euro)peso;
            textBox1.Text=(euro.GetCantidad()).ToString("N");
            textBox4.Text=(dolar.GetCantidad()).ToString("N");
            textBox7.Text=(aux.GetCantidad()).ToString("N");

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox10_TextChanged(object sender, EventArgs e)
        {

        }

        //private void button1_Click(object sender, EventArgs e)
        //{

        //}
    }
}
