﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio 2";
            string aux;
            int num;
            Console.WriteLine("Ingrese un número: ");
            aux=Console.ReadLine();
            while(!(int.TryParse(aux,out num)) || num==0)
            {
                Console.WriteLine("ERROR. ¡Reingresar número! : ");
                aux = Console.ReadLine();
            }
            Console.WriteLine("\nEl cuadrado de {0} es {1} y su cubo es {2}",num,(int)Math.Pow(num,2),(int)Math.Pow(num, 3));
            Console.ReadKey();
        }
    }
}
