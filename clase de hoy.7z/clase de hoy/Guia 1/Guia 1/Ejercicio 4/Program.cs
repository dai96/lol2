﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio 4";
            int i, j, numero;
            for (i = 0; i < 10000; i++)
            {
                numero = 0;
                for (j = 1; j < 10000; j++)
                {
                    if (i % j == 0 && i != j)
                    {
                        numero += j;
                    }
                }
                if (numero == i)
                {
                    Console.WriteLine("{0} es número perfecto", numero);
                }
            }
            Console.ReadLine();
        }
    }
}
