﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio 6";
            int año;
            Console.Write("Ingrese un año ");
            string aux = Console.ReadLine();
            while (!(int.TryParse(aux, out año)))
            {
                Console.WriteLine("ERROR. ¡Reingresar año! : ");
                aux = Console.ReadLine();
            }
            if (año % 4 == 0 && año % 100 != 0 || año % 400 == 0)
            {
                Console.WriteLine("El año {0} es bisiesto", año);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("El año {0} no es bisiesto", año);
                Console.ReadLine();
            }
        }
    }
}
