﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio 1";
            string[] numeros;
            numeros = new string[5];
            int min=0, max=0, prom=0;
            Console.WriteLine("Ingrese 5 numeros: ");
            for (int i=0;i<5;i++)
            {
                    numeros[i]=Console.ReadLine();
                while (!(int.TryParse(numeros[i] ,out int aux)))
                    {
                    Console.WriteLine("Error! Asegurese de que sea un numero: ");
                    numeros[i] = Console.ReadLine();
                    }
                if (i==0)
                {
                    min = int.Parse(numeros[0]);
                    max = int.Parse(numeros[0]);
                }
                
                if (min>int.Parse(numeros[i]))
                {
                    min= int.Parse(numeros[i]);
                }
                if (max<int.Parse(numeros[i]))
                {
                    max = int.Parse(numeros[i]);
                }
                prom = prom+int.Parse(numeros[i]);
            }
            Console.WriteLine("\nEl numero minimo fue: {0}\nEl numero maximo fue: {1}\nEl Promedio fue: {2}", min, max, prom/5);
            Console.ReadKey();

            
        }
    }
}
