﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio 7";
            string aux;
            DateTime date;
            Console.Write("Ingresa tu dia de nacimiento:");
            aux = Console.ReadLine();
            while (!(DateTime.TryParse(aux, out date)))
            {
                Console.WriteLine("ERROR. ¡Reingresar año! : ");
                aux = Console.ReadLine();
            }
            Console.WriteLine("Hasta ahora viviste {0:dd} días", DateTime.Now - date);
            Console.ReadLine();
        }
    }
}
