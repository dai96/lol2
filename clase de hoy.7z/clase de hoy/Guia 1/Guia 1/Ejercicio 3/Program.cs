﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio 3";
            int numero, i ,j,contador = 0;
            string aux;
            Console.WriteLine("Ingrese un numero: ");
            aux= Console.ReadLine();
            while (!(int.TryParse(aux, out numero)))
            {
                Console.WriteLine("ERROR. ¡Reingresar número! : ");
                aux = Console.ReadLine();
            }
            for (i = 0; i <= numero; i++)
            {
                contador = 0;
                for (j = 1; j <= numero; j++)
                {
                    if (i % j == 0)
                    {
                        contador += 1;
                    }
                }
                if (contador == 2)
                {
                    Console.WriteLine("{0} es un numero primo", i);
                }
            }
            Console.ReadLine();
        }
    }
}
