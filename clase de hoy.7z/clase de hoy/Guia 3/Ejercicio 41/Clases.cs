﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_41
{

    abstract class Llamada
    {
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;
        public abstract float CostoLlamada
        {
            get;
        }
        public float Duracion
        {
            get { return this.duracion; }
        }
        public string NroDestino
        {
            get { return this.nroDestino; }
        }
        public string NroOrigen
        {
            get { return this.nroOrigen; }
        }
        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }
        protected virtual string Mostrar()
        {
            StringBuilder miStg = new StringBuilder();

            miStg.AppendLine("\nDuracion: " + Duracion + "\nDestino: " + NroDestino + "\nOrigen: " + NroOrigen);

            return miStg.ToString();
        }
        public static int OrdenarPorDuracion(Llamada llam1, Llamada llam2)
        {
            if (llam1.duracion > llam2.duracion)
            {
                return 1;
            }
            else if (llam1.duracion < llam2.duracion)
            {
                return -1;
            }
            return 0;
        }
        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }
        public static bool operator ==(Llamada l1, Llamada l2)
        {
            if (l1.Equals(l2) && l1.nroDestino == l2.nroDestino && l1.nroOrigen == l2.nroOrigen)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(Llamada l1, Llamada l2)
        {
            return !(l1 == l2);
        }
    }
    class Local : Llamada
    {

        protected float costo;

        public override float CostoLlamada
        {
            get { return this.CalcularCosto(); }
        }

        public Local(string ori, float dur, string dest, float cost) : base(dur, dest, ori)
        {
            this.costo = cost;
        }

        public Local(Llamada llamada, float cost) : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
        {
            this.costo = cost;
        }

        private float CalcularCosto()
        {
            return base.Duracion * this.costo;
        }
        protected override string Mostrar()
        {

            StringBuilder miStg = new StringBuilder();
            miStg.AppendLine(base.Mostrar() + "Costo:" + this.CostoLlamada);
            return miStg.ToString();
        }
        public override bool Equals(object obj)
        {
            if (obj.GetType() == typeof(Local))
            {
                return true;
            }
            return false;
        }
        public override string ToString()
        {
            return Mostrar();
        }

    }
    class Provincial : Llamada
    {
        protected Franja franjaHoraria;

        public enum Franja //podes dividir x 100
        {
            Franja_1,
            Franja_2,
            Franja_3
        }
        public override float CostoLlamada
        {
            get { return this.CalcularCosto(); }
        }

        public Provincial(Franja miFranja, Llamada llamada) : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
        {
            this.franjaHoraria = miFranja;
        }

        public Provincial(string ori, Franja miFranja, float dur, string dest) : base(dur, dest, ori)
        {
            this.franjaHoraria = miFranja;
        }

        private float CalcularCosto()
        {
            float retorno = 0;
            switch (this.franjaHoraria)
            {
                case Franja.Franja_1:
                    retorno = (float)(this.Duracion * 0.99);
                    break;
                case Franja.Franja_2:
                    retorno = (float)(this.Duracion * 125);
                    break;
                case Franja.Franja_3:
                    retorno = (float)(this.Duracion * 0.66);
                    break;
                default:
                    break;
            }
            return retorno;
        }


        public override bool Equals(Object obj)
        {
            if (obj.GetType() == typeof(Provincial)) // obj.is provincial
            {
                return true;
            }
            return false;
        }

        protected override string Mostrar()
        {
            StringBuilder miStg = new StringBuilder();
            string hola = base.Mostrar();
            miStg.AppendLine(hola + " Costo:" + CalcularCosto() + " Franja:" + franjaHoraria);
            return miStg.ToString();
        }

        public override string ToString()
        {
            return Mostrar();
        }





    }
    class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;
        public float GananciasPorLocal
        {
            get { return this.CalcularGanancia(Llamada.TipoLlamada.Local); }
        }
        public float GananciasPorProvincia
        {
            get { return this.CalcularGanancia(Llamada.TipoLlamada.Provincial); }
        }
        public float GananciasPorTotal
        {
            get { return this.CalcularGanancia(Llamada.TipoLlamada.Todas); }
        }
        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }
        private float CalcularGanancia(Llamada.TipoLlamada llamadas)
        {
            float rtn = 0;
            float rtnTodos = 0;
            float rtnProv = 0;
            float rtnLocal = 0;

            foreach (Llamada item in this.Llamadas)
            {
                if (item is Local)
                {
                    rtnTodos += rtnLocal += ((Local)item).CostoLlamada;
                }
                else if (item is Provincial)
                {
                    rtnTodos += rtnProv += ((Provincial)item).CostoLlamada;
                }
            }
            switch (llamadas)
            {
                case Llamada.TipoLlamada.Local:
                    rtn = rtnLocal;
                    break;
                case Llamada.TipoLlamada.Provincial:
                    rtn = rtnProv;
                    break;
                case Llamada.TipoLlamada.Todas:
                    rtn = rtnTodos;
                    break;
                default:
                    break;
            }
            return rtn;
        }
        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }
        public Centralita(string nombreEmpresa) : this()
        {
            this.razonSocial = nombreEmpresa;
        }
        private string Mostrar()
        {
            StringBuilder myStr = new StringBuilder();
            myStr.Append("\nRazon social: " + this.razonSocial + " Ganancia total: " + this.GananciasPorTotal + " Ganancia por llamadas locales: " + this.GananciasPorLocal + " Ganancia por llamadas provinciales: " + this.GananciasPorProvincia);
            myStr.AppendLine("\nDetalle de las llamadas: ");
            foreach (Llamada item in Llamadas)
            {
                if (item is Local)
                {
                    myStr.AppendLine(((Local)item).ToString());
                }
                else if (item is Provincial)
                {
                    myStr.AppendLine(((Provincial)item).ToString());
                }
            }
            return myStr.ToString();
        }
        public void OrdenarLlamadas()
        {
            this.Llamadas.Sort(Llamada.OrdenarPorDuracion);
        }
        public override string ToString()
        {
            return Mostrar();
        }
        public static bool operator ==(Centralita c, Llamada llamada)
        {
            foreach (Llamada item in c.Llamadas)
            {
                if (item == llamada)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Centralita c, Llamada llamada)
        {
            return !(c == llamada);
        }
        public static Centralita operator +(Centralita c, Llamada nuevaLlamada)
        {
            try
            {
                    if (c != nuevaLlamada)
                    {
                        c.AgregarLlamada(nuevaLlamada);
                    }
                    else
                    { throw new CentralitaException("\nLlamada ya existente", "\nClase llamada", "\nMetodo operador +"); }
                
            }
            catch (CentralitaException e)
            {
                Console.Write(e.Message);
                Console.Write(e.NombreClase);
                Console.WriteLine(e.NombreMetodo);
            }
            return c;
        }
        private void AgregarLlamada(Llamada nuevaLlamada)
        {
            this.Llamadas.Add(nuevaLlamada);
        }
    }


    public class CentralitaException : Exception
    {
        private string nombreClase;
        private string nombreMetodo;

        public string NombreClase
        {
            get
            {
                return this.nombreClase;
            }
        }

        public string NombreMetodo
        {
            get
            {
                return this.nombreMetodo;
            }
        }
        public CentralitaException(string mensaje, string clase, string metodo) : this(mensaje, clase, metodo, null)
        {

        }

        public CentralitaException(string mensaje, string clase, string metodo, Exception innerException) : base(mensaje, innerException)
        {
            this.nombreClase = clase;
            this.nombreMetodo = metodo;
        }
    

}

}
