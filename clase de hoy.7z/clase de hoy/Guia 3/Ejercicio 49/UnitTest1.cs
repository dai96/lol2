﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Ejercicio_46
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestListaInstanciada()
        {
            //Competencia competencia = new Competencia(3, 5, Competencia.TipoCompetencia.F1);
            Competencia<AutoF1> competencia = new Competencia<AutoF1>(3, 5, Competencia<AutoF1>.TipoCompetencia.F1);
            Assert.IsNotNull(competencia.Competidores);
        }
        [TestMethod]
        public void Excepcion()
        {
            bool aux;
            Competencia<AutoF1> competencia = new Competencia<AutoF1>(3, 5, Competencia<AutoF1>.TipoCompetencia.MotoCross);
            //Competencia<MotoCross> competencia = new Competencia<MotoCross>(3, 5, Competencia<MotoCross>.TipoCompetencia.MotoCross);
            AutoF1 autoF1 = new AutoF1(1, "lol");

            try
            {
                aux = competencia + autoF1;
            }
            catch(Exception e)
            {
                Assert.IsNotInstanceOfType(e, typeof(CompetenciaNoDisponibleException));
            }
        }
        [TestMethod]
        public void Execpionsdjoasij()
        {
            bool aux;
            Competencia<MotoCross> competencia = new Competencia<MotoCross>(3, 5, Competencia<MotoCross>.TipoCompetencia.MotoCross);
            MotoCross moto = new MotoCross(1, "lol");

            try
            {
                aux = competencia + moto;
            }
            catch (Exception e)
            {
                Assert.Fail("Esta mal esta excepcion");
            }
        }
        [TestMethod]
        public void nuevoVehiculo()
        {
            bool aux;
            Competencia<MotoCross> competencia = new Competencia<MotoCross>(3, 5, Competencia<MotoCross>.TipoCompetencia.MotoCross);
            MotoCross moto = new MotoCross(1, "lol");

            aux = competencia + moto;
            Assert.IsTrue(competencia == moto);
        }
        [TestMethod]
        public void noVehiculo()
        {
            bool aux;
            Competencia<MotoCross> competencia = new Competencia<MotoCross>(3, 5, Competencia<MotoCross>.TipoCompetencia.MotoCross);
            MotoCross moto = new MotoCross(1, "lol");

            aux = competencia + moto;
            aux = competencia - moto;
            Assert.IsTrue(competencia != moto);
        }

    }
}
