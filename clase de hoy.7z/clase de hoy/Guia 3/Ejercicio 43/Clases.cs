﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ejercicio_36
{
    public class Competencia
    {
        private short cantidadCompetidores;
        private short cantidadVueltas;
        private List<VehiculoDeCarrera> competidores;
        private TipoCompetencia tipo;

        public enum TipoCompetencia
        {
            F1,
            MotoCross
        }

        private Competencia()
        {
            this.competidores = new List<VehiculoDeCarrera>();
        }
        public Competencia(short cantidadVueltas, short cantidadCompetidores, TipoCompetencia tipo) : this()
        {
            this.cantidadVueltas = cantidadVueltas;
            this.cantidadCompetidores = cantidadCompetidores;
            this.tipo = tipo;
        }

        public string MostrarDatos()
        {

            StringBuilder myStg = new StringBuilder();
            myStg.Append("\ncantidad de Competidores: " + this.cantidadCompetidores + " Cantidad de vueltas: " + this.cantidadVueltas + " tipo: "+this.Tipo);
            foreach (VehiculoDeCarrera item in this.competidores)
            {
               
                    myStg.AppendFormat(item.MostrarDatos());
                
            }
            return myStg.ToString();
        }
        public static bool operator -(Competencia c, VehiculoDeCarrera a)
        {
            if (c == a)
            {
                c.competidores.Remove(a);
                return true;
            }
            return false;
        }
        public static bool operator +(Competencia c, VehiculoDeCarrera a)
        {
            Thread.Sleep(150);
            Random random = new Random();
            if (c.competidores.Count < c.cantidadCompetidores)
            {
                try
                {
                    if (c != a)
                    {
                        a.EnCompetencia = true;
                        a.VueltasRestantes = c.cantidadVueltas;
                        a.CantidadCombustible = (short)random.Next(15, 100);
                        c.competidores.Add(a);
                        return true;
                    }
                }
                catch (CompetenciaNoDisponibleException e)
                {
                    throw new CompetenciaNoDisponibleException("\nCompetencia incorrecta", "Clase competencia", "Metodo operador +", e); ;
                }
            }
            return false;
        }
        public static bool operator ==(Competencia c, VehiculoDeCarrera a)
        {
            
            bool retorno = false;
            try
            {
                if (c.Tipo == TipoCompetencia.F1 && a is AutoF1)
                {
                    foreach (AutoF1 item in c.competidores)
                    {
                        if (item == ((AutoF1)a))
                        {
                            retorno = true;
                            break;
                        }
                    }
                }
                else if (c.Tipo == TipoCompetencia.MotoCross && a is MotoCross)
                {
                    foreach (MotoCross item in c.competidores)
                    {
                        if (item == ((MotoCross)a))
                        {
                            retorno = true;
                            break;
                        }
                    }
                }
                else
                {
                    throw new CompetenciaNoDisponibleException("\nEl vehiculo no corresponde a la competencia", "Clase Competencia", "Metodo ==");
                }
            }
            catch(CompetenciaNoDisponibleException e)
            {
                throw e;
            }
            return retorno;
        }
        public static bool operator !=(Competencia c, VehiculoDeCarrera a)
        {
            return !(c == a);
        }

        public short CantidadCompetidores
        {
            get { return this.cantidadCompetidores; }
            set { this.cantidadCompetidores = value; }
        }
        public short CantidadVueltas
        {
            get { return this.cantidadCompetidores; }
            set { this.cantidadVueltas = value; }
        }
        public TipoCompetencia Tipo
        {
            get { return this.tipo; }
            set { this.tipo = value; }
        }
        public VehiculoDeCarrera this[int i]
        {
            get { return this.competidores[i]; }
        }
    }

    public class VehiculoDeCarrera
    {
        private short cantidadCombustible;
        private bool enCompetencia;
        private string escuderia;
        private short numero;
        private short vueltasRestantes;

        public VehiculoDeCarrera(short numero, string escuderia)
        {
            this.cantidadCombustible = 0;
            this.enCompetencia = false;
            this.escuderia = escuderia;
            this.numero = numero;
            this.vueltasRestantes = 0;
        }
        public virtual string MostrarDatos()
        {
            string competencia = "No está compitiendo";
            StringBuilder myStg = new StringBuilder();
            myStg.Append("\n\nNumero: " + this.numero + " Escuderia: " + this.escuderia);
            if (this.enCompetencia == true)
            {
                competencia = "Está compitiendo";
            }
            myStg.Append("\nEstado: " + competencia + " Vueltas restantes: " + this.vueltasRestantes + " Combustible disponible: " + this.cantidadCombustible);
            return myStg.ToString();

        }


        public short CantidadCombustible
        {
            get { return this.cantidadCombustible; }
            set { this.cantidadCombustible = value; }
        }
        public bool EnCompetencia
        {
            get { return this.enCompetencia; }
            set { this.enCompetencia = value; }
        }
        public short Numero
        {
            get { return this.numero; }
            set { this.numero = value; }
        }
        public short VueltasRestantes
        {
            get { return this.vueltasRestantes; }
            set { this.vueltasRestantes = value; }
        }
        public string Escuderia
        {
            get { return this.escuderia; }
            set { this.escuderia = value; }
        }
    }
    public class AutoF1:VehiculoDeCarrera
    {

        private short caballosDeFuerza;
        public AutoF1(short numero, string escuderia):base(numero,escuderia)
        {}
        public AutoF1(short numero, string escuderia, short caballosDeFuerza) : this(numero, escuderia)
        {
            this.caballosDeFuerza = caballosDeFuerza;
        }
        public override string MostrarDatos()
        {
              StringBuilder stg = new StringBuilder();
                stg.AppendLine(base.MostrarDatos());
                stg.AppendFormat("\nCaballos de fuerza: {0}", this.caballosDeFuerza);

                return stg.ToString();
            

        }

        public static bool operator ==(AutoF1 a1, AutoF1 a2)
        {
            if (a1.Escuderia == a2.Escuderia && a1.Numero==a2.Numero  && a1.caballosDeFuerza==a2.caballosDeFuerza)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(AutoF1 a1, AutoF1 a2)
        {
            return !(a1 == a2);
        }

        public short CaballosDeFuerza
        {
            get { return this.caballosDeFuerza; }
            set { this.caballosDeFuerza = value; }
        }

    }

    public class MotoCross : VehiculoDeCarrera
    {
        private short cilindrada;

        public MotoCross(short numero, string escuderia) : base(numero, escuderia)
        { }
        public MotoCross(short numero, string escuderia, short cilindrada) : this(numero, escuderia)
        {
            this.cilindrada = cilindrada;
        }
        public override string MostrarDatos()
        {
           
                StringBuilder stg = new StringBuilder();
                stg.AppendLine(base.MostrarDatos());
                stg.AppendFormat("\nCilindrada: {0}", this.cilindrada);
                return stg.ToString();

        }

        public static bool operator ==(MotoCross m1, MotoCross m2)
        {
            if (m1.Escuderia == m2.Escuderia && m1.Numero == m2.Numero && m1.cilindrada == m2.cilindrada)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(MotoCross m1, MotoCross m2)
        {
            return !(m1 == m2);
        }

        public short Cilindrada
        {
            get { return this.cilindrada; }
            set { this.cilindrada = value; }
        }
    }


    public class CompetenciaNoDisponibleException:Exception
    {
        private string nombreClase;
        private string nombreMetodo;

        public string NombreClase
        {
            get {return this.nombreClase;}
        }
        public string NombreMetodo
        {
            get { return this.nombreMetodo; }
        }

        public CompetenciaNoDisponibleException(string msj, string clase, string metodo) : this(msj, clase, metodo,null)
        {
            
        }
        public CompetenciaNoDisponibleException(string msj, string clase, string metodo, CompetenciaNoDisponibleException innerException): base (msj, innerException)
        {
            this.Source=this.nombreClase = clase;
            this.nombreMetodo = metodo;
        }

        public string ToString()
        {
            StringBuilder msg = new StringBuilder();
            msg.AppendFormat("\nExcepcion en {0} de {1}", this.nombreMetodo, this.nombreClase);
            msg.AppendFormat(this.Message);
            msg.AppendFormat("\nExcepcion original: {0}\tClase: {1}", this.InnerException.Message, this.InnerException.Source);
            return msg.ToString();
        }
    }
}
