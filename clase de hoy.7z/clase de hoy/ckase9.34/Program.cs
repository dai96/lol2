﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ckase9._34
{
    class Program
    {
        static void Main(string[] args)
        {
            Automovil a1 = new Automovil(4, 5, "Negro", 0, 1);


        }
    }
    class Automovil:VehiculoTerrestre
    {
        short cantidadManchas;
        int cantidadPasajeros;

        public Automovil(short cantidadRuedas, short cantidadPuertas, Colores color, short cantidadManchas, int cantidadPasajeros):base(cantidadRuedas,cantidadPuertas,color)
        {
            this.cantidadManchas = cantidadManchas;
            this.cantidadPasajeros = cantidadPasajeros;
        }

    }
    class Moto:VehiculoTerrestre
    {
        short cilindrada;

        public Moto(short cantidadRuedas, short cantidadPuertas, Colores color, short cilindrada):base(cantidadRuedas,cantidadPuertas,color)
        {
            this.cilindrada = cilindrada;
        }
    }
    class Camion:VehiculoTerrestre
    {
        short cantidadManchas;
        int pesoCarga;
        public Camion(short cantidadRuedas, short cantidadPuertas, Colores color, short cantidadManchas, int pesoCarga):base(cantidadRuedas,cantidadPuertas,color)
        {
            
            this.cantidadManchas = cantidadManchas;
            this.pesoCarga = pesoCarga;
        }

    }
    class VehiculoTerrestre
    {
        private short cantidadRuedas;
        private short cantidadPuertas;
        private Colores color;

        public VehiculoTerrestre(short cantidadRuedas, short cantidadPuertas, Colores color)
        {
            this.cantidadRuedas = cantidadRuedas;
            this.cantidadPuertas = cantidadPuertas;
            this.color = color;
        }
    }
    public enum Colores
    {
        Rojo,
        Blanco,
        Azul,
        Gris,
        Negro
    }
}
