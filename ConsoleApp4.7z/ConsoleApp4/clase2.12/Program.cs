﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._12
{
    class Program
    {
        static void Main(string[] args)
        {
            bool bol = true;
            char key;
            String lol;
            do
            {
                Console.WriteLine("Ingrese un número: ");
                Console.WriteLine("Continuar? S/N");
               // lol = Console.ReadKey();
                //char.TryParse(lol, out key);
               // bol = Class2.ValidaS_N(key);
            } while (bol = false);

        }
    }
}
