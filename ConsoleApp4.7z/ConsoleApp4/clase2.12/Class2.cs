using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._12
{
    public static class Class2
    {
        public static bool ValidaS_N(char c)
        {

            bool rtn=false;
            if (c.Equals('S'))
            {
               rtn = true;
            }
            if (c.Equals('N'))
            {
              rtn = false;
            }
            return rtn;
        }
    }
}
