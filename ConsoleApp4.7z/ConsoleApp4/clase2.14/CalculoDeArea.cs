﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._14
{
    public static class CalculoDeArea
    {
        public static double CalcularCuadrado(double num)
        {
            double rtn;
            rtn = num * 2;
            return rtn;

        }
        public static double CalcularTriangulo(double baseAux, double alturaAux)
        {
            double rtn;
            rtn = baseAux * alturaAux;
            return rtn;
        }
        public static double CalcularCirculo(double num)   
        {
            double rtn;
            rtn = Math.PI * (Math.Pow(num, 2));
            return rtn;

        }

    }
}
