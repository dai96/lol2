﻿using System; 


+

 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._14
{
    class Program
    {
        static void Main(string[] args)
        {
            string aux;
            int x;  
            Console.WriteLine("Bienvenido a la caluladora de areas!");
            Console.WriteLine("seleccione el calculo que desea");
            Console.WriteLine("1.Cuadrado \n 2.Trinagulo \n 3.Circulo");
            aux = Console.ReadLine();

            x=int.Parse(aux);

            if (x == 1)
            {
                double num;
                Console.WriteLine("ingrese lado");
                aux = Console.ReadLine();
                double.TryParse(aux, out num);
                num=CalculoDeArea.CalcularCuadrado(num);
                Console.WriteLine("{0}", num);
                Console.ReadKey();


            }
            if (x==2)
            {
                double bas, alt, resp;
                Console.WriteLine("ingrese base");
                aux = Console.ReadLine();
                double.TryParse(aux, out bas);
                Console.WriteLine("ingrese altura");
                aux = Console.ReadLine();
                double.TryParse(aux, out alt);
                resp = CalculoDeArea.CalcularTriangulo(bas, alt);
                Console.WriteLine("{0}", resp);
                Console.ReadKey();

            }
            if (x==3)
            {
                double num;
                Console.WriteLine("ingrese radio");
                aux = Console.ReadLine();
                double.TryParse(aux, out num);
                num = CalculoDeArea.CalcularCirculo(num);
                Console.WriteLine("{0}", num);
                Console.ReadKey();
            }

        }
    }
}
