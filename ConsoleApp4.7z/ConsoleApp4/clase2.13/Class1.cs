using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._13
{
  public static class Conversor
  {
    public static string DecimalBinario(double x)

    {
      string cadena = "hola";

      if (x > 0)
      {
        cadena = "";
        while (x > 0)
        {
          if (x % 2 == 0)
          {
            cadena = "0" + cadena;

          }
          else
          {
            cadena = "1" + cadena;

          }
          x = (int)x / 2;
        }
        return cadena;
      }

      return cadena;

    }
    public static double BinarioDecimal(string x)
    {
      double y;
      int i;

     y = double.Parse(x);
      for (i = 0; i <= x.Length; i++)
      {
        
        if (x[i] == '1')
        {
          Console.WriteLine("aver");
        }

      }
      return i;
    }
  }
}
