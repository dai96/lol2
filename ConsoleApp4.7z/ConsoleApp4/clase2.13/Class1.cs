﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._13
{
    public static class Conversor
    {
        public static string DecimalBinario(double x)
        {
             
            if (x > 0)
            {
                String cadena = "";
                while (x > 0)
                {
                    if (x % 2 == 0)
                    {
                        cadena = "0" + cadena;
                        
                    }
                    else
                    {
                        cadena = "1" + cadena;
                       
                    }
                    x = (double)(x / 2);
                }
                Console.WriteLine(cadena);
                return cadena;
            }
            string lol="hola";
            return lol;

        }
       // public static double BinarioDecimal(string x)
        //{

        //}
    }
}
