using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._13
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            string respuesta, aux;
            

            Console.WriteLine("Ingrese un numero: ");
           respuesta = Console.ReadLine();
           numero = Conversor.BinarioDecimal(respuesta);
      Console.WriteLine("{0}", numero);
           // aux = Console.ReadLine();
            //double.TryParse(aux, out numero);
            //respuesta= Conversor.DecimalBinario(numero);
      //Console.WriteLine("{0}", respuesta);
            Console.ReadKey();
        }
    }
}

