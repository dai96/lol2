﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
          string aux;
            int num, i, j, contador=0;
            bool parser=false;
            do
            {
                Console.Write("Ingrese un numero: ");
                aux = Console.ReadLine();
                parser = int.TryParse(aux, out num);
                if (parser)
                {
                    //Console.WriteLine("lograaaado");
                    for (i=1;i<num;i++)
                    {
                        for (j=1;j<i;j++)
                        {
                            contador = contador + j;

                        }
                        
                    }
                }
                else
                {
                    Console.WriteLine("Error! vuelva a intentar");
                    continue;//ACA SIEMPRE CONTINUE NO BREAK
                }
            } while (!(parser));
          
          Console.ReadKey();  
        }
    }
}
