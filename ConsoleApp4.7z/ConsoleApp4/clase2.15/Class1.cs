﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._15
{
    static class Calculadora
    {
        public static float Calcular (float x, float y, char signo)
        {

        }
        private static bool validar (int y)
        {
            
        }
    }
}
