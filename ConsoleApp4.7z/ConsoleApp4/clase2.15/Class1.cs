using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2._15
{
    static class Calculadora
    {
    public static float Calcular (float a, float b, char signo)
    {
      float rtn=0;
      bool hacer;
      if (signo.Equals('+'))
      {
        rtn = a + b;
      }
      if (signo.Equals('-'))
      {
        rtn = a - b;
      }
      if (signo.Equals('*'))
      {
        rtn = a * b;
      }
      if (signo.Equals('/'))
      {
        hacer=Calculadora.Validar(b);
        if (hacer==true)
        {
          rtn = a / b;
        }
        else
        {
          Console.WriteLine("el 2do numero es 0");
          Console.ReadKey();
        }
      }
      return rtn;
    }
    private static bool Validar (float b)
    {
      bool rtn = false;
      if (b!=0)
      {
        rtn = true;
      }
      return rtn;
    }
    }
}
