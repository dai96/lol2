﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, num = 0, valor=0;

                for (i = 1; i < int.MaxValue; i++)
                {
                    for (j = 1; j < i; j++)
                    {
                        if (i % j == 0)
                        {
                            valor = valor + j;
                        }

                    }
                    if (valor == i)
                    {
                        num++;
                        Console.WriteLine("{0}", i);
                    }
                    valor = 0;
                    if (num==4)
                    {
                        break;
                    }
                }
            Console.WriteLine("logrado");
            Console.ReadKey();
           

        }
    }
}
