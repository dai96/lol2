﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio11
{
    class Program
    {
        static void Main(string[] args)
        {
            bool equis;

            equis=Class1.validar(10, 0, 9);

            if (equis)
            {
                Console.Write("es true");
            }
            else
            {
                Console.Write("es false");
            }
            Console.ReadKey();
        }
    }
}
