﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase3._16
{
    class Alumno
    {
        byte nota1;
        byte nota2;
        float notaFinal;
        string apellido;
        int legajo;
        string nombre;

        public datos(string name, string surname, int leg)
        {
            this.apellido = surname;
            this.nombre = name;
            this.legajo = leg;
            this.nota1 = 0;
            this.nota2 = 0;
            this.notaFinal = 0;
        }
    }
}
