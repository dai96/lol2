﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase3._16
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno alumno1 = new Alumno("lara", "lopez", 8);
           Alumno alumno2 = new Alumno("juan", "perez", 19);
           Alumno alumno3 = new Alumno("lola", "bunny", 29);

          
        }
    }
}
