using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using library;

namespace FrmCantina
{
  public partial class FrmBar : Form
  {
    public Edificio edificio = Edificio.GetBar();
    public FrmBar()
    {
      InitializeComponent();
    }

    private void FrmBar_Load(object sender, EventArgs e)
    {
      IsMdiContainer = true;
    

    }

    private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
    {

    }

    private void agregarToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FrmCantidadEspaciosCantina frmcnt = new FrmCantidadEspaciosCantina();
      frmcnt.ShowDialog();
      if (frmcnt.DialogResult==DialogResult.OK)
      {
        short i=frmcnt.CantidadEspacios;
        FrmCantina frm = new FrmCantina();
        if (this.edificio+frm.GetCantina)
        {
          frm.MdiParent = this;
          frm.Show();
        }

      }
    }

    private void barrasToolStripMenuItem_Click(object sender, EventArgs e)
    {
       // this.MdiChildren.GetCan
    }
  }
}
