using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
  public abstract class Botella
  {
    protected int capacidadML;
    protected int contenidoML;
    protected string marca;

    public int CapacidadLitros
    {
      get { return this.capacidadML / 1000; }
    }
    public int Contenido
    {
      get { return this.contenidoML; }
      set { this.contenidoML = value; }
    }
    public abstract  float PorcentajeContenido
    {
      get;
    }

    protected Botella(string marca, int capacidadML, int contenidoML)
    {
      if (capacidadML < contenidoML)
      {
        this.contenidoML = capacidadML;
        this.capacidadML = CapacidadLitros;
        this.marca = marca;
      }
      else
      {
        this.capacidadML = capacidadML;
        this.contenidoML = contenidoML;
        this.marca = marca;
      }
    }

    protected virtual string GenerarInforme()
    {
      StringBuilder stringBuild = new StringBuilder();
      stringBuild.AppendFormat("Marca: {0}\n", this.marca);
      stringBuild.AppendFormat("Contenido: {0}\n", this.contenidoML);
      stringBuild.AppendFormat("Capacidad: {0}\n", this.CapacidadLitros);
      stringBuild.AppendFormat("Porcenjate: {0}%", this.PorcentajeContenido);

      return stringBuild.ToString();
    }
    public abstract int ServirMedida();

 /*   public virtual string ToString()
    {
      return GenerarInforme();
    }*/
    public static implicit operator string(Botella b)
    {
      return b.GenerarInforme();
    }
    public static bool operator ==(Botella b1,Botella b2)
    {
      return (b1.marca == b2.marca);
    }
    public static bool operator !=(Botella b1, Botella b2)
    {
      return !(b1==b2);
    }
    public enum Tipo
    {
      Plastico,
      Vidrio
    }
  }
}
