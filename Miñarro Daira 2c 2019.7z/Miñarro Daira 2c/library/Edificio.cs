using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
  public sealed class Edificio
  {
    private Cantina[] cantinas=null;
    private const short limiteCantinas = 2;
    private static Edificio singleton;

    private Edificio()
    {
      this.cantinas = new Cantina[limiteCantinas];
    }
    static Edificio()
      {
        singleton = new Edificio();
      }

    public static Edificio GetBar()
    {
        return singleton = new Edificio();
      
    }
    public static bool operator +(Edificio e, Cantina c)
    {
      bool rtn = false;
      for(short i=0; i<limiteCantinas; i++)
      {
        if (e.cantinas[i] is null)
        {
          e.cantinas[i] = c;
          return rtn;
        }
      }
 
      return rtn;
    }
  }
}
