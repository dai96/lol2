﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Entidades
{
    public static class PaqueteDAO
    {
        static SqlCommand comando;
        static SqlConnection conexion;
    }
  
    static PaqueteDAO()
    {
        PaqueteDAO.conexion = new SqlConnection(Properties.Settings.Default.conexion);
        PaqueteDAO.comando = new SqlCommand();

    }
 
    public static bool Insertar(Paquete p)
    {
        PaqueteDAO.comando.CommandType = System.Data.CommandType.Text;
        PaqueteDAO.comando.CommandText = String.Format("INSERT INTO Paquetes values('{0}','{1}','{2}')", p.DireccionEntrega, p.TrackingID, "Agustin Gomez");
        PaqueteDAO.comando.Connection = PaqueteDAO.conexion;
        try
        {
            PaqueteDAO.conexion.Open();
            PaqueteDAO.comando.ExecuteNonQuery();
            PaqueteDAO.conexion.Close();
        }
        catch (Exception e)
        {
            throw e;
        }
        return true;
    }


    public static bool Insertar(Paquete p)
    {
        bool retorno = false;
        comando.CommandText = string.Format("INSERT INTO Paquetes values ('{0}','{1}','{2}')", p.DireccionEntrega, p.TrackingID, "Luciano Moreno");
        comando.CommandType = System.Data.CommandType.Text;

        try
        {
            conexion.Open();
            comando.ExecuteNonQuery();
            retorno = true;
        }
        catch (Exception e)
        {
            // Acá va el mensaje de excepcion.

            throw e;
        }

        finally
        {
            conexion.Close();
        }
        return retorno;
    }
}
