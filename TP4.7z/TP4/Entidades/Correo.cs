﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Entidades
{
    public class Correo: IMostar<List<Paquete>>
    {
        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;
        
        public List<Paquete> Paquetes
        {
            get { return this.paquetes; }
            set { this.paquetes = value; }
        }
        public Correo()
        {
            this.mockPaquetes = new List<Thread>();
            this.Paquetes = new List<Paquete>();
        }
        public void FinEntregas()
        {
            foreach (Thread item in this.mockPaquetes)
            {
                item.Abort();
            }
        }
        public string MostrarDatos(IMostar<List<Paquete>>elementos)
        {
            StringBuilder stg = new StringBuilder();
            foreach(Paquete item in ((Correo)elementos).paquetes)
            {
                stg.AppendFormat("{0} para {1}({2})", item.TrackingID, item.DireccionEntrega, item.Estado.ToString());
            }
            return stg.ToString();
        }
        public static Correo operator +(Correo c, Paquete p)
        {
            foreach (Paquete item in c.paquetes)
            {
                if (item == p)
                {
                    throw new TrackingIdRepetidoException("Repetido");
                }
            }
            c.paquetes.Add(p);
            Thread hilo = new Thread(p.MockCicloDeVida); //creo hilo
            c.mockPaquetes.Add(hilo);//lo agrego a mockpaquetes
            hilo.Start();//lo ejecuto
            return c;
        }
    }
}


/*
 * 2.Este guardará en un archivo de texto en el escritorio de la máquina.3.
 * Recibirá como parámetro el nombre del archivo.4.Si el archivo existe, agregaráinformación en él.
 * PaqueteDAOClase estática que se encargará de guardar los datos de un paquete en la base de datos generada
 * anteriormente:A.De surgir cualquier error con la carga de datos, se deberá lanzar una excepcióntantas veces como
 * sea necesario hasta llegar a la vista (formulario).A través de un MessageBox informar lo ocurrido al usuario de 
 * forma clara.De ser necesario, utilizar un evento para este fin.B.El campo alumno de la base de datos deberá contener 
 * el nombre del alumno que está realizando el TP.Paquete1.Implementar la interfaz IMostrar, siendo su tipo genérico 
 * Paquete.2.MostrarDatos utilizará string.Format con el siguiente formato "{0} para {1}", p.trackingID, p.direccionEntregapara 
 * compilar la información del paquete.3.La sobrecarga del método ToString retornará la información del paquete.4.Dos paquetes 
 * serán iguales siempre y cuando su Tracking ID sea el mismo.5.MockCicloDeVida hará que el paquete cambie de estado de la 
 * siguiente forma:a.Colocar una demora de 4segundos.b.Pasar al siguiente estado.c.Informar el estado a través de InformarEstado.
 * EventArgs no tendrá ningún dato extra.d.Repetir las acciones desde el punto A hasta que el estado sea Entregado.e.Finalmente 
 * guardar los datos del paquete en la base de datosCorreo1.Implementará la interfaz IMostrar<List<Paquete>>.2.En el operador 
 * +:a.Controlar si el paquete ya está en la lista. En el caso de que esté, se lanzará la excepción TrackingIdRepetidoException.b.De no estar repetido, agregar el paquete a la lista de paquetes.c.Crear un hilo para el método MockCicloDeVidadel paquete, y agregar dicho hilo a mockPaquetes.d.Ejecutar el hilo.3.MostrarDatos utilizará string.Format con el siguiente formato "{0} para {1} ({2})", p.TrackingID, p.DireccionEntrega, p.Estado.ToString()para retornar los datos de todos los paquetes de su lista.4.FinEntregascerrará todos los hilos activos.Formulario1.El Título del formulario deberá contener los datos del alumno,reemplazando donde dice Nombre.Apellido.Division en la imagen provista.2.Se deberá respetar el diseño visto en la imagen, siendo los elementos a utilizar: GroupBox, ListBox, Label, RichTextBox, MaskedTextBox, TextBox, ContextMenuStrip (para el ListBox lstEstadoEntregado) y Button.3.El evento click del botón btnAgregar realizará las siguientes acciones en el siguiente orden:a.Creará un nuevo paquete y asociará al evento InformaEstado el método paq_InformaEstado.b.Agregará el paquete al correo, controlando las excepciones que puedan derivar de dicha acción.c.Llamará al método ActualizarEstados.4.Al cerrarse el formulario, se deberá llamar al método FinEntregas a fin de cerrar todos los hilos abiertos.5.paq_InformaEstadollamará al método ActualizarEstados en el ELSEdel siguiente códigoif(this.InvokeRequired){Paquete.DelegadoEstadod = newPaquete.DelegadoEstado(paq_InformaEstado);
this.Invoke( d, newobject[] {sender, e} );}else{ // Llamar al método}6.El botón btnMostrarTodoscontendrá sólo la siguiente línea 
de código:this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);7.El menú mostrarToolStripMenuItemcontendrá 
sólo la siguiente línea de código:this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lstEstadoEntregado.SelectedItem);
8.El método MostrarInformacion<T>evaluará que el atributo elemento no sea nuloy:a.Mostrará los datos de elemento en el rtbMostrar
.b.Utilizará el método de extensión para guardar los datos en un archivo llamado salida.txt.9.El método ActualizarEstadoslimpiará
los 3 ListBox y luego recorrerá la lista de paquetes agregando cada uno de ellos en el listado que corres
*/