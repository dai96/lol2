﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmPpal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }
    }
}

/*no carga dos veces igual
[TestMethod]
public void VerificarCargaDosPaquetesMimosTrackingId()
{
    Paquete paqueteUno = new Paquete("España", "123");
    Paquete paqueteDos = new Paquete("Argentina", "123");
    Correo correoNuevo = new Correo();

    try
    {
        correoNuevo += paqueteUno;
        correoNuevo += paqueteDos;
        Assert.Fail("Estoy intentando añadir 2 paquetes del mismo tracking. Tendria que lanzar una exception.");
    }
    catch (Exception e)
    {
        Assert.IsInstanceOfType(e, typeof(TrackingIdRepetidoException));
    }
}


    para que este instanciada verificar not null

    */

/*
 *  public partial class FrmPpal : Form
    {
        private Correo correo;
        
        public FrmPpal()
        {
            InitializeComponent();
            correo = new Correo();
        }


        private void FrmPpal_Load(object sender, EventArgs e)
        {

        }


        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete  paquete = new Paquete( this.txtDireccion.Text, this.mtxtTrackingID.Text);

            paquete.InformaEstado += new Paquete.DelegadoEstado(paq_InformaEstado);
            try
            {
                correo += paquete;
            }
            catch (TrackingIdRepetidoException ex)
            {
                MessageBox.Show(ex.Message);
            }

            this.ActualizarEstados();

        }


        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
        }


        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lstEstadoEntregado.SelectedItem);
        }


        private void txtDireccion_TextChanged(object sender, EventArgs e)
        {

        }


        private void FrmPpal_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.correo.FinEntregas();
        }


        #region ActualizarEstados

        public void ActualizarEstados()
        {

            lstEstadoIngresado.Items.Clear();
            lstEstadoEnViaje.Items.Clear();
            lstEstadoEntregado.Items.Clear();

            foreach (Paquete item in correo.Paquetes)
            {
                switch (item.Estado)
                {
                    case Paquete.EEstado.Ingresado:
                        lstEstadoIngresado.Items.Add(item);
                        break;
                    case Paquete.EEstado.EnViaje:
                        lstEstadoEnViaje.Items.Add(item);
                        break;
                    case Paquete.EEstado.Entregado:
                        lstEstadoEntregado.Items.Add(item);
                        break;
                    default:
                        break;
                }
            }
        }

        #endregion

        #region paq_InformaEstado

        private void paq_InformaEstado(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke(d, new object[] { sender, e });
            }
            else
            {
                this.ActualizarEstados();
            }

        }

        #endregion

        #region MostrarInformacion

        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            string cadena = "";

            if (!(Object.Equals(elemento, null)))
            {
                this.rtbMostrar.Text = elemento.MostrarDatos(elemento);

                try
                {
                    cadena = elemento.MostrarDatos(elemento);
                    cadena.Guardar("salida.txt");
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }

            }
        }*/
