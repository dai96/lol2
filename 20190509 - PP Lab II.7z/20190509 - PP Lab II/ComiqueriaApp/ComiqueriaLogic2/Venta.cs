using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
sealed class Venta
  {
    private DateTime fecha;
    private static int porcentajeiva;
    private double precioFinal;
    private Producto producto;

    internal DateTime Fecha
    {
      get { return this.fecha; }
    }
    public static double CalcularPrecioFinal(double precioUnidad, int cantidad)
    {
      double precio = precioUnidad * cantidad;
      return precio = (precio * porcentajeiva) / 100;
     }
    public string ObtenerDescripcionBreve()
    {
      StringBuilder myStg = new StringBuilder();
      myStg.AppendFormat("fecha{0}descripcion{1}preciof{2}", this.Fecha, this.producto.Descripcion, this.precioFinal);

      return myStg.ToString();
    }
    private void Vender(int cantidad)
    {
      this.producto.Stock = this.producto.Stock - cantidad;
      this.fecha = DateTime.Now;
      this.precioFinal = CalcularPrecioFinal(this.producto.Precio, cantidad);
    }
   static Venta()
    {
      porcentajeiva = 21;
    }
    internal Venta(Producto producto, int cantidad)
    {
      this.producto = producto;
      Vender(cantidad);
    }
  }
}
