using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public class Comic : Producto
  {
    private string autor;
    private TipoComic tipoComic;

    public enum TipoComic
    {
      Occidental,
      Oriental
    }
    public Comic (string descripcion, int stock, double precio, string autor, TipoComic tipoComic): base(descripcion,stock,precio)
    {
      this.autor = autor;
      this.tipoComic = tipoComic;
    }
    public override string ToString()
    {
      StringBuilder myStr = new StringBuilder();
      string hola=base.ToString();
      myStr.AppendFormat("{0}", hola);
      myStr.AppendFormat("{0}", this.autor);
      myStr.AppendFormat("{0}", this.tipoComic);
      return myStr.ToString();
    }
  }
}
