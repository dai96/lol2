using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public class Comiqueria
  {
    private List<Producto> producto;
    private List<Venta> ventas;

    public Producto this[Guid codigo]
    {
      get
      {
        foreach (Producto item in producto)
        {
          if ((Guid)item == codigo)
          {
            return item;
          }
        }
        return null;
      }
    }

    public Comiqueria()
    {
      this.producto = new List<Producto>();
      this.ventas = new List<Venta>();
    }
    public Dictionary<Guid, string> ListarProductos()
    { }
    public string ListarVentas()
    { }
    public static bool operator ==(Comiqueria comiqueria, Producto producto)
    {
      
    }
    public static bool operator !=(Comiqueria comiqueria, Producto producto)
    { }
    public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
    { }

    public void Vender(Producto producto)
    { }
    public void Vender(Producto producto, int cantidad)
    { }
  }
}
