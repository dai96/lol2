using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public class Comiqueria
  {
    private List<Producto> producto;
    private List<Venta> ventas;

    public Producto this[Guid codigo]
    {
      get
      {
        foreach (Producto item in producto)
        {
          if ((Guid)item == codigo)
          {
            return item;
          }
        }
        return null;
      }
    }

    public Comiqueria()
    {
      this.producto = new List<Producto>();
      this.ventas = new List<Venta>();
    }
    /*public Dictionary<Guid, string> ListarProductos()
    {

    }
    public string ListarVentas()
    { }*/
    public static bool operator ==(Comiqueria comiqueria, Producto producto)
    {
      foreach(Producto item in comiqueria.producto)
      {
        if (item.Equals(comiqueria.producto))
        {
          return true;
        }
      }
      return false;
    }
    public static bool operator !=(Comiqueria comiqueria, Producto producto)
    {
      return !(comiqueria == producto);
    }
    public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
    {
      if (comiqueria!=producto)
      {
        comiqueria.producto.Add(producto);
        return comiqueria;
      }
      return comiqueria;
    }

    public void Vender(Producto producto)
    {
      Vender(producto, 1);
    }
    public void Vender(Producto producto, int cantidad)
    {
      Venta vent = new Venta(producto,cantidad);
      ventas.Add(vent);
    }
  }
}
