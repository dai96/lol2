﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio11
{
    public static class Class1
    {
        public static bool validar(int valor, int min, int max)
        {
            if (valor>max)
            {
                return false;
            }
            if (valor<min)
            {
                return false;
            }
            return true;

        }
    }
}
