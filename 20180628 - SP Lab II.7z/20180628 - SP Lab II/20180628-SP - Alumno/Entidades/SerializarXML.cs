using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Execepciones;
using System.IO;

namespace Entidades
{
  public class SerializarXML<T> : IArchivos<T>
  {
    public T Leer(string rutaArchivo, T objeto)
    {
      using (TextReader reader = new StreamReader(rutaArchivo))
      {

        XmlSerializer serializer = new XmlSerializer(typeof(T));
        objeto = (T)serializer.Deserialize(reader);
        if (objeto is T)
        {
          return (T)objeto;
        }
        else
        {
          throw new ErrorArchivoException();
        }
      }
    }
      public bool Guardar(string rutaArchivo, T objeto)
      {
        using (TextWriter writer = new StreamWriter(rutaArchivo))
        {
          XmlSerializer serializer = new XmlSerializer(typeof(T));
          serializer.Serialize(writer, objeto);
          if (objeto is T)
        {
          return true;
        }
          else
        {
          throw new ErrorArchivoException();
        }
        }

      }

   }
}
