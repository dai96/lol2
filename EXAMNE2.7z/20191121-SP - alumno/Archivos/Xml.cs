﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace Archivos
{
    public class Xml<T> : IFiles<T>
    {
       
        public string GetDirectoryPath
        {
            get { return "C:...Desktop "; }
        }

        public bool FileExist(string nombreArchivo)
        {
            if (File.Exists(nombreArchivo))
            {
                return true;
            }
            return false;
        }
        void Guardar(string nombreArchivo, T objeto)
        {
            try
            {
                using (TextWriter writer = new StreamWriter(nombreArchivo))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(T));
                    serializer.Serialize(writer, objeto);
                    if (objeto is T)
                    {

                    }

                }
            }
            catch(Exception e)
            {
                throw new ErrorArchivosExepcion("Error en guardado", e);
            }
            
            finally
            {
               
            }
        }
        void Guardar(string nombreArchivo, T objeto, Encoding encoding)
        {

        }

        bool Leer(string nombreArchivo, out T objeto)
        {
            try
            {
                using (TextReader reader = new StreamReader(nombreArchivo))
                {
                    XmlSerializer xml = new XmlSerializer(typeof(T));
                    objeto = (T)xml.Deserialize(reader);
                }
            }
            catch (Exception e)
            {
                throw new ErrorArchivosExepcion("Error en Lectura",e);
            }
            return true;
        }
        bool Leer(string nombreArchivo, out T objeto, Encoding encoding)
        {
            TextReader reader = new StreamReader(nombreArchivo);
            XmlSerializer xml = new XmlSerializer(typeof(T));
            objeto = (T)xml.Deserialize(reader);
            return true;
        }

    }
}




