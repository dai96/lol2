using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Numero
  {
    private double numero;

    public Numero()
    {
      this.numero = 0;
    }
    public Numero(double num)
    {
      this.numero = num;
    }
    public Numero(string num) : this(double.Parse(num))
    {
    }

    public static string DecimalBinario(double x)
    {
      string cadena = "Valor invalido";

      if (x > 0)
      {
        cadena = "";
        while (x > 0)
        {

          if (x % 2 == 0)
          {
            cadena = "0" + cadena;

          }
          else
          {
            cadena = "1" + cadena;

          }
          x = (int)x / 2;
        }
        return cadena;
      }

      return cadena;
    }

    public static string DecimalBinario(string x)
    {
      return DecimalBinario(Double.Parse(x));
    }

    public static double BinarioDecimal(string x)
    {
      int l = x.Length;
      int i;
      double resp = 0;

      for (i = 1; i <= l; i++)
      {

        byte n = byte.Parse(x.Substring(l - i, 1));
        if (n == 1)
        {
          resp += System.Math.Pow(2, i - 1);
        }

      }
      return resp;
    }


    public static double operator +(Numero a, Numero b)
    {
      return a.numero + b.numero;
    }
    public static double operator -(Numero a, Numero b)
    {
      return a.numero - b.numero;

    }
    public static double operator *(Numero a, Numero b)
    {
      return a.numero * b.numero;

    }
    public static double operator /(Numero a, Numero b)
    {
      if (b.numero == 0)
      {
        return double.MinValue;
      }
      return a.numero / b.numero;
    }

    private double ValidarNumero(string numero)
    {
      double rtn = 0;
      if (double.TryParse(numero, out rtn))
      {
        return rtn;
      }
      return rtn;
    }

    private string SetNumero
    {
      set   {
            numero=ValidarNumero(value);
             
            }

    }
  }
}
